export interface Post {
  id: string
  user_id: string
  content: string
  media_urls?: string[]
  media_type?: "image" | "video" | "mixed"
  privacy: "public" | "friends" | "private"
  likes_count: number
  comments_count: number
  shares_count: number
  created_at: string
  updated_at: string
  profiles: {
    display_name: string
    avatar_url?: string
  }
}

export interface Comment {
  id: string
  post_id: string
  user_id: string
  parent_id?: string
  content: string
  likes_count: number
  created_at: string
  updated_at: string
  profiles: {
    display_name: string
    avatar_url?: string
  }
  replies?: Comment[]
}

export async function createPost(data: {
  content: string
  media_urls?: string[]
  media_type?: string
  privacy?: string
}) {
  const response = await fetch("/api/posts", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })

  if (!response.ok) {
    throw new Error("Failed to create post")
  }

  return response.json()
}

export async function getPosts(page = 1, limit = 10) {
  const response = await fetch(`/api/posts?page=${page}&limit=${limit}`)

  if (!response.ok) {
    throw new Error("Failed to fetch posts")
  }

  return response.json()
}

export async function likePost(postId: string, reactionType = "like") {
  const response = await fetch(`/api/posts/${postId}/like`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ reaction_type: reactionType }),
  })

  if (!response.ok) {
    throw new Error("Failed to like post")
  }

  return response.json()
}

export async function unlikePost(postId: string) {
  const response = await fetch(`/api/posts/${postId}/like`, {
    method: "DELETE",
  })

  if (!response.ok) {
    throw new Error("Failed to unlike post")
  }

  return response.json()
}

export async function addComment(postId: string, content: string, parentId?: string) {
  const response = await fetch(`/api/posts/${postId}/comments`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ content, parent_id: parentId }),
  })

  if (!response.ok) {
    throw new Error("Failed to add comment")
  }

  return response.json()
}
