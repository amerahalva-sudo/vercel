export interface LiveStream {
  id: string
  user_id: string
  title: string
  description?: string
  category: string
  privacy: "public" | "friends" | "private"
  status: "scheduled" | "live" | "ended" | "cancelled"
  stream_key?: string
  rtmp_url?: string
  hls_url?: string
  thumbnail_url?: string
  viewer_count: number
  max_viewers: number
  likes_count: number
  comments_count: number
  allow_comments: boolean
  allow_sharing: boolean
  started_at?: string
  ended_at?: string
  duration_seconds: number
  created_at: string
  updated_at: string
  profiles: {
    display_name: string
    avatar_url?: string
  }
  current_viewers?: number
}

export interface StreamChatMessage {
  id: string
  stream_id: string
  user_id: string
  message: string
  message_type: "text" | "emoji" | "system"
  created_at: string
  profiles: {
    display_name: string
    avatar_url?: string
  }
}

export async function createStream(streamData: {
  title: string
  description?: string
  category: string
  privacy: string
  allow_comments: boolean
  allow_sharing: boolean
}) {
  const response = await fetch("/api/streams", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(streamData),
  })

  if (!response.ok) {
    throw new Error("Failed to create stream")
  }

  return response.json()
}

export async function getStreams(status = "live", category?: string, page = 1, limit = 10) {
  const params = new URLSearchParams({
    status,
    page: page.toString(),
    limit: limit.toString(),
  })

  if (category) {
    params.append("category", category)
  }

  const response = await fetch(`/api/streams?${params}`)

  if (!response.ok) {
    throw new Error("Failed to fetch streams")
  }

  return response.json()
}

export async function getStream(streamId: string) {
  const response = await fetch(`/api/streams/${streamId}`)

  if (!response.ok) {
    throw new Error("Failed to fetch stream")
  }

  return response.json()
}

export async function updateStream(streamId: string, updates: Partial<LiveStream>) {
  const response = await fetch(`/api/streams/${streamId}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(updates),
  })

  if (!response.ok) {
    throw new Error("Failed to update stream")
  }

  return response.json()
}

export async function joinStream(streamId: string) {
  const response = await fetch(`/api/streams/${streamId}/join`, {
    method: "POST",
  })

  if (!response.ok) {
    throw new Error("Failed to join stream")
  }

  return response.json()
}

export async function leaveStream(streamId: string) {
  const response = await fetch(`/api/streams/${streamId}/leave`, {
    method: "POST",
  })

  if (!response.ok) {
    throw new Error("Failed to leave stream")
  }

  return response.json()
}

export async function sendChatMessage(streamId: string, message: string, messageType = "text") {
  const response = await fetch(`/api/streams/${streamId}/chat`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      message,
      message_type: messageType,
    }),
  })

  if (!response.ok) {
    throw new Error("Failed to send chat message")
  }

  return response.json()
}

export async function getChatMessages(streamId: string, limit = 50) {
  const response = await fetch(`/api/streams/${streamId}/chat?limit=${limit}`)

  if (!response.ok) {
    throw new Error("Failed to fetch chat messages")
  }

  return response.json()
}
