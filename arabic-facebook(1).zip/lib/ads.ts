export interface Advertisement {
  id: string
  user_id: string
  title: string
  description: string
  ad_type: "image" | "video" | "carousel" | "text"
  media_urls?: string[]
  cta_text: string
  cta_link?: string
  target_audience: Record<string, any>
  budget_daily: number
  budget_total?: number
  duration_days: number
  status: "pending" | "approved" | "active" | "paused" | "completed" | "rejected"
  start_date?: string
  end_date?: string
  impressions: number
  clicks: number
  conversions: number
  spent_amount: number
  created_at: string
  updated_at: string
  profiles: {
    display_name: string
    avatar_url?: string
  }
  analytics?: {
    impressions: number
    clicks: number
    likes: number
    comments: number
    shares: number
  }
}

export async function createAd(adData: {
  title: string
  description: string
  ad_type: string
  cta_text: string
  cta_link?: string
  target_audience: Record<string, any>
  budget_daily: number
  duration_days: number
}) {
  const response = await fetch("/api/ads", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(adData),
  })

  if (!response.ok) {
    throw new Error("Failed to create ad")
  }

  return response.json()
}

export async function getAds(status?: string, page = 1, limit = 10) {
  const params = new URLSearchParams({
    page: page.toString(),
    limit: limit.toString(),
  })

  if (status) {
    params.append("status", status)
  }

  const response = await fetch(`/api/ads?${params}`)

  if (!response.ok) {
    throw new Error("Failed to fetch ads")
  }

  return response.json()
}

export async function getAd(adId: string) {
  const response = await fetch(`/api/ads/${adId}`)

  if (!response.ok) {
    throw new Error("Failed to fetch ad")
  }

  return response.json()
}

export async function updateAd(adId: string, updates: Partial<Advertisement>) {
  const response = await fetch(`/api/ads/${adId}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(updates),
  })

  if (!response.ok) {
    throw new Error("Failed to update ad")
  }

  return response.json()
}

export async function deleteAd(adId: string) {
  const response = await fetch(`/api/ads/${adId}`, {
    method: "DELETE",
  })

  if (!response.ok) {
    throw new Error("Failed to delete ad")
  }

  return response.json()
}

export async function interactWithAd(adId: string, interactionType: string, metadata?: Record<string, any>) {
  const response = await fetch(`/api/ads/${adId}/interact`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      interaction_type: interactionType,
      metadata,
    }),
  })

  if (!response.ok) {
    throw new Error("Failed to record interaction")
  }

  return response.json()
}

export async function getFeedAds(limit = 5) {
  const response = await fetch(`/api/ads/feed?limit=${limit}`)

  if (!response.ok) {
    throw new Error("Failed to fetch feed ads")
  }

  return response.json()
}
