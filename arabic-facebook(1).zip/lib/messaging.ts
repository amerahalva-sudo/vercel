export interface Conversation {
  id: string
  type: "direct" | "group"
  name?: string
  avatar_url?: string
  created_at: string
  updated_at: string
  lastMessage?: string
  lastMessageTime?: string
  unreadCount: number
  otherParticipant?: {
    display_name: string
    avatar_url?: string
  }
  participants?: ConversationParticipant[]
}

export interface ConversationParticipant {
  user_id: string
  joined_at: string
  last_read_at: string
  profiles: {
    display_name: string
    avatar_url?: string
  }
}

export interface Message {
  id: string
  conversation_id: string
  sender_id: string
  content: string
  message_type: "text" | "image" | "video" | "file" | "audio"
  media_url?: string
  reply_to_id?: string
  created_at: string
  updated_at: string
  profiles: {
    display_name: string
    avatar_url?: string
  }
  reply_to?: {
    content: string
    profiles: {
      display_name: string
    }
  }
}

export async function getConversations(): Promise<{ conversations: Conversation[] }> {
  const response = await fetch("/api/conversations")
  if (!response.ok) {
    throw new Error("Failed to fetch conversations")
  }
  return response.json()
}

export async function createConversation(participantId: string, type = "direct", name?: string) {
  const response = await fetch("/api/conversations", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      participant_id: participantId,
      type,
      name,
    }),
  })

  if (!response.ok) {
    throw new Error("Failed to create conversation")
  }

  return response.json()
}

export async function getMessages(conversationId: string, page = 1, limit = 50): Promise<{ messages: Message[] }> {
  const response = await fetch(`/api/conversations/${conversationId}/messages?page=${page}&limit=${limit}`)
  if (!response.ok) {
    throw new Error("Failed to fetch messages")
  }
  return response.json()
}

export async function sendMessage(
  conversationId: string,
  content: string,
  messageType = "text",
  mediaUrl?: string,
  replyToId?: string,
) {
  const response = await fetch(`/api/conversations/${conversationId}/messages`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      content,
      message_type: messageType,
      media_url: mediaUrl,
      reply_to_id: replyToId,
    }),
  })

  if (!response.ok) {
    throw new Error("Failed to send message")
  }

  return response.json()
}

export async function getConversation(conversationId: string) {
  const response = await fetch(`/api/conversations/${conversationId}`)
  if (!response.ok) {
    throw new Error("Failed to fetch conversation")
  }
  return response.json()
}
