"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Home, Users, MessageCircle, Bell, User, TrendingUp, ImageIcon, Video } from "lucide-react"
import { LanguageSwitcher } from "@/components/language-switcher"
import Link from "next/link"
import Image from "next/image"

export function Header() {
  return (
    <header className="bg-card border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/feed" className="flex items-center gap-2">
            <Image src="/fais-urduni-logo.png" alt="فيس اردني" width={32} height={32} className="rounded-lg" />
            <h1 className="text-2xl font-bold text-primary cursor-pointer">{"فيس اردني"}</h1>
          </Link>
          <div className="relative hidden md:block">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input placeholder="البحث في فيس اردني" className="w-64 pr-10 text-right" />
          </div>
        </div>

        <nav className="flex items-center gap-2">
          <Link href="/feed">
            <Button variant="ghost" size="icon" className="text-primary">
              <Home className="w-5 h-5" />
            </Button>
          </Link>
          <Link href="/friends">
            <Button variant="ghost" size="icon">
              <Users className="w-5 h-5" />
            </Button>
          </Link>
          <Link href="/messenger">
            <Button className="font-sans" variant="ghost" size="icon">
              <MessageCircle className="w-5 h-5" />
            </Button>
          </Link>
          <Link href="/live">
            <Button variant="ghost" size="icon">
              <Video className="w-5 h-5" />
            </Button>
          </Link>
          <Link href="/media">
            <Button variant="ghost" size="icon">
              <ImageIcon className="w-5 h-5" />
            </Button>
          </Link>
          <Link href="/ads">
            <Button variant="ghost" size="icon">
              <TrendingUp className="w-5 h-5" />
            </Button>
          </Link>
          <Button variant="ghost" size="icon">
            <Bell className="w-5 h-5" />
          </Button>
          <Link href="/profile">
            <Button variant="ghost" size="icon">
              <User className="w-5 h-5" />
            </Button>
          </Link>
          <LanguageSwitcher />
        </nav>
      </div>
    </header>
  )
}
