"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, UserPlus, UserMinus, MessageCircle, MoreHorizontal, Users, UserCheck } from "lucide-react"

interface Friend {
  id: string
  name: string
  avatar: string
  mutualFriends: number
  status: "friend" | "pending" | "suggested" | "blocked"
  lastActive?: string
  location?: string
}

const mockFriends: Friend[] = [
  {
    id: "1",
    name: "علي أحمد",
    avatar: "/ali-profile.png",
    mutualFriends: 12,
    status: "friend",
    lastActive: "منذ 5 دقائق",
    location: "الرياض",
  },
  {
    id: "2",
    name: "فاطمة علي",
    avatar: "/serene-woman-profile.png",
    mutualFriends: 8,
    status: "friend",
    lastActive: "منذ ساعة",
    location: "جدة",
  },
  {
    id: "3",
    name: "محمد حسن",
    avatar: "/mohammed-profile.png",
    mutualFriends: 15,
    status: "friend",
    lastActive: "منذ يوم",
    location: "الدمام",
  },
  {
    id: "4",
    name: "نورا سالم",
    avatar: "/nora-profile.png",
    mutualFriends: 6,
    status: "pending",
    location: "مكة",
  },
  {
    id: "5",
    name: "خالد العتيبي",
    avatar: "/khalid-profile.png",
    mutualFriends: 3,
    status: "suggested",
    location: "الطائف",
  },
  {
    id: "6",
    name: "سارة أحمد",
    avatar: "/sarah-profile.png",
    mutualFriends: 9,
    status: "suggested",
    location: "الرياض",
  },
]

const friendRequests: Friend[] = [
  {
    id: "7",
    name: "أحمد الشمري",
    avatar: "/ahmed-shamri-profile.png",
    mutualFriends: 4,
    status: "pending",
    location: "حائل",
  },
  {
    id: "8",
    name: "ليلى محمد",
    avatar: "/layla-profile.png",
    mutualFriends: 7,
    status: "pending",
    location: "المدينة",
  },
]

export function FriendsManager() {
  const [searchQuery, setSearchQuery] = useState("")
  const [friends, setFriends] = useState<Friend[]>(mockFriends)
  const [requests, setRequests] = useState<Friend[]>(friendRequests)

  const handleFriendAction = (friendId: string, action: "add" | "remove" | "accept" | "decline" | "block") => {
    console.log(`${action} friend:`, friendId)

    if (action === "accept") {
      const request = requests.find((r) => r.id === friendId)
      if (request) {
        setRequests((prev) => prev.filter((r) => r.id !== friendId))
        setFriends((prev) => [...prev, { ...request, status: "friend" }])
      }
    } else if (action === "decline") {
      setRequests((prev) => prev.filter((r) => r.id !== friendId))
    } else if (action === "add") {
      setFriends((prev) => prev.map((f) => (f.id === friendId ? { ...f, status: "pending" } : f)))
    } else if (action === "remove") {
      setFriends((prev) => prev.filter((f) => f.id !== friendId))
    }
  }

  const filteredFriends = friends.filter((friend) => friend.name.toLowerCase().includes(searchQuery.toLowerCase()))

  const FriendCard = ({ friend, showActions = true }: { friend: Friend; showActions?: boolean }) => (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <img
            src={friend.avatar || "/placeholder.svg?height=60&width=60&query=user-avatar"}
            alt={friend.name}
            className="w-15 h-15 rounded-full object-cover"
          />
          <div className="flex-1">
            <h3 className="font-semibold hover:underline cursor-pointer">{friend.name}</h3>
            <p className="text-sm text-muted-foreground">{friend.mutualFriends} صديق مشترك</p>
            {friend.location && <p className="text-xs text-muted-foreground">{friend.location}</p>}
            {friend.lastActive && <p className="text-xs text-muted-foreground">نشط {friend.lastActive}</p>}

            {showActions && (
              <div className="flex gap-2 mt-3">
                {friend.status === "friend" && (
                  <>
                    <Button size="sm" variant="outline" className="gap-2 bg-transparent">
                      <MessageCircle className="w-4 h-4" />
                      رسالة
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleFriendAction(friend.id, "remove")}>
                      <UserMinus className="w-4 h-4" />
                    </Button>
                  </>
                )}
                {friend.status === "suggested" && (
                  <Button size="sm" className="gap-2" onClick={() => handleFriendAction(friend.id, "add")}>
                    <UserPlus className="w-4 h-4" />
                    إضافة صديق
                  </Button>
                )}
                {friend.status === "pending" && <Badge variant="secondary">طلب معلق</Badge>}
              </div>
            )}
          </div>
          <Button variant="ghost" size="icon">
            <MoreHorizontal className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">الأصدقاء</h1>
        <div className="relative">
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="البحث عن الأصدقاء"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-64 pr-10 text-right"
          />
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all" className="gap-2">
            <Users className="w-4 h-4" />
            جميع الأصدقاء ({friends.filter((f) => f.status === "friend").length})
          </TabsTrigger>
          <TabsTrigger value="requests" className="gap-2">
            <UserCheck className="w-4 h-4" />
            طلبات الصداقة ({requests.length})
          </TabsTrigger>
          <TabsTrigger value="suggestions" className="gap-2">
            <UserPlus className="w-4 h-4" />
            اقتراحات ({friends.filter((f) => f.status === "suggested").length})
          </TabsTrigger>
          <TabsTrigger value="online">الأصدقاء المتصلون</TabsTrigger>
        </TabsList>

        <div className="mt-6">
          <TabsContent value="all" className="space-y-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredFriends
                .filter((friend) => friend.status === "friend")
                .map((friend) => (
                  <FriendCard key={friend.id} friend={friend} />
                ))}
            </div>
          </TabsContent>

          <TabsContent value="requests" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>طلبات الصداقة</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {requests.map((request) => (
                  <div key={request.id} className="flex items-center gap-3 p-3 border border-border rounded-lg">
                    <img
                      src={request.avatar || "/placeholder.svg?height=50&width=50&query=user-avatar"}
                      alt={request.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold">{request.name}</h3>
                      <p className="text-sm text-muted-foreground">{request.mutualFriends} صديق مشترك</p>
                      {request.location && <p className="text-xs text-muted-foreground">{request.location}</p>}
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => handleFriendAction(request.id, "accept")}>
                        قبول
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleFriendAction(request.id, "decline")}>
                        رفض
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="suggestions" className="space-y-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {friends
                .filter((friend) => friend.status === "suggested")
                .map((friend) => (
                  <FriendCard key={friend.id} friend={friend} />
                ))}
            </div>
          </TabsContent>

          <TabsContent value="online" className="space-y-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {friends
                .filter((friend) => friend.status === "friend" && friend.lastActive?.includes("دقائق"))
                .map((friend) => (
                  <FriendCard key={friend.id} friend={friend} />
                ))}
            </div>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}
