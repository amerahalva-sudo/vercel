"use client"

import type React from "react"

import { useState, useRef, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, X, ImageIcon, Video, Camera, Folder } from "lucide-react"

interface MediaFile {
  id: string
  type: "image" | "video"
  url: string
  file: File
  thumbnail?: string
}

interface MediaUploaderProps {
  onUpload: (files: MediaFile[]) => void
  onClose: () => void
}

export function MediaUploader({ onUpload, onClose }: MediaUploaderProps) {
  const [selectedFiles, setSelectedFiles] = useState<MediaFile[]>([])
  const [dragActive, setDragActive] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFiles = useCallback(
    (files: FileList) => {
      const newFiles: MediaFile[] = []

      Array.from(files).forEach((file) => {
        if (file.type.startsWith("image/") || file.type.startsWith("video/")) {
          const mediaFile: MediaFile = {
            id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
            type: file.type.startsWith("image/") ? "image" : "video",
            url: URL.createObjectURL(file),
            file,
          }
          newFiles.push(mediaFile)
        }
      })

      setSelectedFiles([...selectedFiles, ...newFiles])
    },
    [selectedFiles],
  )

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      e.stopPropagation()
      setDragActive(false)

      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        handleFiles(e.dataTransfer.files)
      }
    },
    [handleFiles],
  )

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFiles(e.target.files)
    }
  }

  const removeFile = (id: string) => {
    setSelectedFiles(selectedFiles.filter((file) => file.id !== id))
  }

  const handleUpload = () => {
    onUpload(selectedFiles)
    setSelectedFiles([])
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>إضافة صور وفيديوهات</CardTitle>
              <CardDescription>اختر الملفات من جهازك أو اسحبها وأفلتها هنا</CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          <Tabs defaultValue="upload" className="space-y-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="upload">رفع ملفات</TabsTrigger>
              <TabsTrigger value="camera">كاميرا</TabsTrigger>
              <TabsTrigger value="library">مكتبة الوسائط</TabsTrigger>
            </TabsList>

            <TabsContent value="upload" className="space-y-4">
              {/* Drag and Drop Area */}
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  dragActive ? "border-primary bg-primary/5" : "border-border"
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">اسحب وأفلت الملفات هنا</h3>
                <p className="text-muted-foreground mb-4">أو انقر لاختيار الملفات من جهازك</p>
                <Button onClick={() => fileInputRef.current?.click()}>
                  <Folder className="w-4 h-4 ml-2" />
                  اختيار ملفات
                </Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept="image/*,video/*"
                  onChange={handleFileInput}
                  className="hidden"
                />
                <p className="text-xs text-muted-foreground mt-2">
                  يدعم: JPG, PNG, GIF, MP4, MOV (حد أقصى 100 ميجابايت لكل ملف)
                </p>
              </div>

              {/* Selected Files Preview */}
              {selectedFiles.length > 0 && (
                <div className="space-y-4">
                  <h4 className="font-semibold">الملفات المحددة ({selectedFiles.length})</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {selectedFiles.map((file) => (
                      <div key={file.id} className="relative group">
                        <div className="relative rounded-lg overflow-hidden bg-muted aspect-square">
                          {file.type === "image" ? (
                            <img
                              src={file.url || "/placeholder.svg"}
                              alt="معاينة"
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="relative w-full h-full">
                              <video src={file.url} className="w-full h-full object-cover" muted />
                              <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                                <Video className="w-6 h-6 text-white" />
                              </div>
                            </div>
                          )}
                          <Button
                            variant="destructive"
                            size="icon"
                            className="absolute top-2 left-2 w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => removeFile(file.id)}
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                        <p className="text-xs text-center mt-1 truncate">{file.file.name}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="camera" className="space-y-4">
              <div className="text-center py-12">
                <Camera className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">التقاط صورة أو فيديو</h3>
                <p className="text-muted-foreground mb-4">استخدم كاميرا جهازك لالتقاط محتوى جديد</p>
                <Button>
                  <Camera className="w-4 h-4 ml-2" />
                  فتح الكاميرا
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="library" className="space-y-4">
              <div className="text-center py-12">
                <ImageIcon className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">مكتبة الوسائط</h3>
                <p className="text-muted-foreground mb-4">اختر من الصور والفيديوهات المحفوظة مسبقاً</p>
                <Button variant="outline">
                  <Folder className="w-4 h-4 ml-2" />
                  تصفح المكتبة
                </Button>
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex gap-3 pt-6 border-t border-border">
            <Button
              onClick={handleUpload}
              disabled={selectedFiles.length === 0}
              className="flex-1 bg-primary hover:bg-primary/90"
            >
              إضافة ({selectedFiles.length}) ملف
            </Button>
            <Button variant="outline" onClick={onClose}>
              إلغاء
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
