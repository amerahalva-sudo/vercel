"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { X, Upload, Target, DollarSign } from "lucide-react"

interface CreateAdFormProps {
  onClose: () => void
}

export function CreateAdForm({ onClose }: CreateAdFormProps) {
  const [adData, setAdData] = useState({
    title: "",
    description: "",
    targetAudience: "",
    budget: "",
    duration: "",
    adType: "",
    ctaText: "تعرف أكثر",
    ctaLink: "",
    image: null as File | null,
  })
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch("/api/ads", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: adData.title,
          description: adData.description,
          ad_type: adData.adType,
          cta_text: adData.ctaText,
          cta_link: adData.ctaLink,
          target_audience: { audience: adData.targetAudience },
          budget_daily: Number.parseFloat(adData.budget),
          duration_days: getDurationDays(adData.duration),
        }),
      })

      if (response.ok) {
        onClose()
        // Refresh the ads list
        window.location.reload()
      } else {
        const error = await response.json()
        console.error("Error creating ad:", error)
      }
    } catch (error) {
      console.error("Error creating ad:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const getDurationDays = (duration: string) => {
    switch (duration) {
      case "1-day":
        return 1
      case "3-days":
        return 3
      case "1-week":
        return 7
      case "2-weeks":
        return 14
      case "1-month":
        return 30
      default:
        return 7
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>إنشاء إعلان جديد</CardTitle>
              <CardDescription>أنشئ إعلانك وحدد الجمهور المستهدف</CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Ad Content */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Upload className="w-5 h-5" />
                محتوى الإعلان
              </h3>

              <div className="space-y-2">
                <Label htmlFor="title">عنوان الإعلان</Label>
                <Input
                  id="title"
                  placeholder="اكتب عنوان جذاب لإعلانك"
                  value={adData.title}
                  onChange={(e) => setAdData({ ...adData, title: e.target.value })}
                  className="text-right"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">وصف الإعلان</Label>
                <Textarea
                  id="description"
                  placeholder="اكتب وصف مفصل عن منتجك أو خدمتك"
                  value={adData.description}
                  onChange={(e) => setAdData({ ...adData, description: e.target.value })}
                  className="text-right min-h-[100px]"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="adType">نوع الإعلان</Label>
                <Select value={adData.adType} onValueChange={(value) => setAdData({ ...adData, adType: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر نوع الإعلان" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="image">إعلان بصورة</SelectItem>
                    <SelectItem value="video">إعلان بفيديو</SelectItem>
                    <SelectItem value="carousel">إعلان متعدد الصور</SelectItem>
                    <SelectItem value="text">إعلان نصي</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="ctaText">نص الزر</Label>
                  <Input
                    id="ctaText"
                    placeholder="تعرف أكثر"
                    value={adData.ctaText}
                    onChange={(e) => setAdData({ ...adData, ctaText: e.target.value })}
                    className="text-right"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ctaLink">رابط الزر</Label>
                  <Input
                    id="ctaLink"
                    placeholder="https://example.com"
                    value={adData.ctaLink}
                    onChange={(e) => setAdData({ ...adData, ctaLink: e.target.value })}
                    className="text-right"
                  />
                </div>
              </div>
            </div>

            {/* Targeting */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Target className="w-5 h-5" />
                استهداف الجمهور
              </h3>

              <div className="space-y-2">
                <Label htmlFor="targetAudience">الجمهور المستهدف</Label>
                <Select
                  value={adData.targetAudience}
                  onValueChange={(value) => setAdData({ ...adData, targetAudience: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="اختر الجمهور المستهدف" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع المستخدمين</SelectItem>
                    <SelectItem value="age-18-25">الأعمار 18-25</SelectItem>
                    <SelectItem value="age-26-35">الأعمار 26-35</SelectItem>
                    <SelectItem value="age-36-50">الأعمار 36-50</SelectItem>
                    <SelectItem value="jordan">المقيمين في الأردن</SelectItem>
                    <SelectItem value="interests-tech">المهتمين بالتكنولوجيا</SelectItem>
                    <SelectItem value="interests-food">المهتمين بالطعام</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Budget & Schedule */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                الميزانية والجدولة
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="budget">الميزانية اليومية (دينار أردني)</Label>
                  <Input
                    id="budget"
                    type="number"
                    placeholder="50"
                    value={adData.budget}
                    onChange={(e) => setAdData({ ...adData, budget: e.target.value })}
                    className="text-right"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="duration">مدة الإعلان</Label>
                  <Select value={adData.duration} onValueChange={(value) => setAdData({ ...adData, duration: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر المدة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1-day">يوم واحد</SelectItem>
                      <SelectItem value="3-days">3 أيام</SelectItem>
                      <SelectItem value="1-week">أسبوع واحد</SelectItem>
                      <SelectItem value="2-weeks">أسبوعين</SelectItem>
                      <SelectItem value="1-month">شهر واحد</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button type="submit" className="flex-1 bg-primary hover:bg-primary/90" disabled={isLoading}>
                {isLoading ? "جاري الإنشاء..." : "إنشاء الإعلان"}
              </Button>
              <Button type="button" variant="outline" onClick={onClose}>
                إلغاء
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
