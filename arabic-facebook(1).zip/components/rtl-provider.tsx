"use client"

import type React from "react"

import { createContext, useContext, useState } from "react"

interface RTLContextType {
  isRTL: boolean
  toggleDirection: () => void
  setDirection: (direction: "rtl" | "ltr") => void
}

const RTLContext = createContext<RTLContextType | undefined>(undefined)

export function RTLProvider({ children }: { children: React.ReactNode }) {
  const [isRTL, setIsRTL] = useState(true) // Default to RTL for Arabic

  const toggleDirection = () => {
    setIsRTL(!isRTL)
    document.documentElement.dir = !isRTL ? "rtl" : "ltr"
    document.documentElement.lang = !isRTL ? "ar" : "en"
  }

  const setDirection = (direction: "rtl" | "ltr") => {
    const newIsRTL = direction === "rtl"
    setIsRTL(newIsRTL)
    document.documentElement.dir = direction
    document.documentElement.lang = newIsRTL ? "ar" : "en"
  }

  return <RTLContext.Provider value={{ isRTL, toggleDirection, setDirection }}>{children}</RTLContext.Provider>
}

export function useRTL() {
  const context = useContext(RTLContext)
  if (context === undefined) {
    throw new Error("useRTL must be used within an RTLProvider")
  }
  return context
}
