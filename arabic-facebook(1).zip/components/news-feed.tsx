"use client"

import { PostCard } from "@/components/post-card"
import { CreatePost } from "@/components/create-post"
import { StoriesSection } from "@/components/stories-section"
import { SponsoredPost } from "@/components/sponsored-post"

const mockPosts = [
  {
    id: "1",
    author: "أحمد محمد",
    content: "يوم جميل في الرياض! الطقس رائع والجو مثالي للنزهة مع العائلة.",
    timestamp: "منذ ساعتين",
    likes: 15,
    comments: 3,
    shares: 2,
    image: "/beautiful-day-in-riyadh.png",
    avatar: "/ahmed-profile.png",
  },
  {
    id: "2",
    author: "فاطمة علي",
    content: "تهانينا لجميع الخريجين! بداية جديدة ومستقبل مشرق إن شاء الله 🎓",
    timestamp: "منذ 4 ساعات",
    likes: 42,
    comments: 8,
    shares: 5,
    avatar: "/serene-woman-profile.png",
  },
  {
    id: "3",
    author: "محمد حسن",
    content: "وصفة كبسة الدجاج التقليدية من جدتي رحمها الله. طعم لا يُنسى!",
    timestamp: "منذ يوم",
    likes: 28,
    comments: 12,
    shares: 15,
    image: "/traditional-chicken-kabsa-dish.png",
    avatar: "/mohammed-profile.png",
  },
  {
    id: "4",
    author: "سارة أحمد",
    content: "زيارة رائعة لمتحف الملك عبدالعزيز اليوم. تاريخ عريق وتراث أصيل يستحق الفخر.",
    timestamp: "منذ يومين",
    likes: 35,
    comments: 6,
    shares: 8,
    image: "/king-abdulaziz-museum-visit.png",
    avatar: "/sarah-profile.png",
  },
  {
    id: "5",
    author: "عبدالله الشمري",
    content: "مشاركة في مؤتمر التقنية السعودي 2024. أفكار مبتكرة ومستقبل واعد للتكنولوجيا في المملكة.",
    timestamp: "منذ 3 أيام",
    likes: 67,
    comments: 15,
    shares: 22,
    image: "/saudi-tech-conference-2024.png",
    avatar: "/abdullah-profile.png",
  },
]

const sponsoredAds = [
  {
    id: "ad-1",
    title: "مطعم الأصالة الأردنية",
    description: "اكتشف أشهى المأكولات الأردنية التقليدية في قلب عمان. طعم أصيل وجودة عالية بأسعار مناسبة.",
    image: "/traditional-jordanian-restaurant.png",
    avatar: "/restaurant-logo.png",
    sponsor: "مطعم الأصالة",
    ctaText: "احجز طاولتك الآن",
    ctaLink: "/restaurant-booking",
  },
  {
    id: "ad-2",
    title: "تعلم البرمجة من الصفر",
    description: "انضم إلى أكاديمية البرمجة الرائدة في الأردن. دورات شاملة مع مدربين خبراء وشهادات معتمدة.",
    image: "/programming-academy.png",
    avatar: "/academy-logo.png",
    sponsor: "أكاديمية الكود",
    ctaText: "سجل الآن واحصل على خصم 30%",
    ctaLink: "/programming-courses",
  },
]

export function NewsFeed() {
  return (
    <div className="space-y-6">
      <StoriesSection />

      <CreatePost />

      <div className="space-y-4">
        <PostCard key={mockPosts[0].id} post={mockPosts[0]} />
        <PostCard key={mockPosts[1].id} post={mockPosts[1]} />

        {/* First sponsored post after 2 regular posts */}
        <SponsoredPost ad={sponsoredAds[0]} />

        <PostCard key={mockPosts[2].id} post={mockPosts[2]} />
        <PostCard key={mockPosts[3].id} post={mockPosts[3]} />

        {/* Second sponsored post after 2 more regular posts */}
        <SponsoredPost ad={sponsoredAds[1]} />

        <PostCard key={mockPosts[4].id} post={mockPosts[4]} />
      </div>

      <div className="text-center py-6">
        <button className="text-primary hover:underline font-medium">تحميل المزيد من المنشورات</button>
      </div>
    </div>
  )
}
