"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MoreHorizontal, Play, Pause, Edit, Trash2, BarChart3 } from "lucide-react"

const mockAds = [
  {
    id: "1",
    title: "مطعم الأصالة الأردنية",
    description: "أشهى المأكولات الأردنية التقليدية في قلب عمان",
    status: "active",
    budget: "75 دينار/يوم",
    reach: "2,543",
    clicks: "156",
    image: "/traditional-jordanian-restaurant.png",
  },
  {
    id: "2",
    title: "متجر الإلكترونيات الحديثة",
    description: "أحدث الأجهزة الإلكترونية بأفضل الأسعار",
    status: "paused",
    budget: "100 دينار/يوم",
    reach: "1,892",
    clicks: "89",
    image: "/modern-electronics-store.png",
  },
  {
    id: "3",
    title: "أكاديمية تعلم البرمجة",
    description: "تعلم البرمجة من الصفر حتى الاحتراف",
    status: "completed",
    budget: "50 دينار/يوم",
    reach: "5,234",
    clicks: "312",
    image: "/programming-academy.png",
  },
]

export function AdsList() {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">نشط</Badge>
      case "paused":
        return <Badge variant="secondary">متوقف</Badge>
      case "completed":
        return <Badge variant="outline">مكتمل</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-4">
      {mockAds.map((ad) => (
        <Card key={ad.id}>
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <Avatar className="w-16 h-16 rounded-lg">
                <AvatarImage src={ad.image || "/placeholder.svg"} alt={ad.title} />
                <AvatarFallback className="rounded-lg">{ad.title.charAt(0)}</AvatarFallback>
              </Avatar>

              <div className="flex-1 space-y-2">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold text-lg">{ad.title}</h3>
                    <p className="text-muted-foreground">{ad.description}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {getStatusBadge(ad.status)}
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="flex items-center gap-6 text-sm text-muted-foreground">
                  <span>الميزانية: {ad.budget}</span>
                  <span>الوصول: {ad.reach}</span>
                  <span>النقرات: {ad.clicks}</span>
                </div>

                <div className="flex items-center gap-2 pt-2">
                  {ad.status === "active" ? (
                    <Button variant="outline" size="sm">
                      <Pause className="w-4 h-4 ml-1" />
                      إيقاف
                    </Button>
                  ) : (
                    <Button variant="outline" size="sm">
                      <Play className="w-4 h-4 ml-1" />
                      تشغيل
                    </Button>
                  )}
                  <Button variant="outline" size="sm">
                    <Edit className="w-4 h-4 ml-1" />
                    تعديل
                  </Button>
                  <Button variant="outline" size="sm">
                    <BarChart3 className="w-4 h-4 ml-1" />
                    التحليلات
                  </Button>
                  <Button variant="outline" size="sm" className="text-destructive bg-transparent">
                    <Trash2 className="w-4 h-4 ml-1" />
                    حذف
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
