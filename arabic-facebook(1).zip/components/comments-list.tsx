"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MoreHorizontal, Send } from "lucide-react"

interface Comment {
  id: string
  author: string
  content: string
  timestamp: string
  likes: number
  avatar?: string
  replies?: Comment[]
}

interface CommentsListProps {
  postId: string
}

const mockComments: Comment[] = [
  {
    id: "1",
    author: "علي أحمد",
    content: "صور رائعة! أتمنى لك يوماً سعيداً",
    timestamp: "منذ ساعة",
    likes: 3,
    avatar: "/ali-profile.png",
    replies: [
      {
        id: "1-1",
        author: "أحمد محمد",
        content: "شكراً لك يا علي، كان يوماً مميزاً فعلاً",
        timestamp: "منذ 45 دقيقة",
        likes: 1,
        avatar: "/ahmed-profile.png",
      },
    ],
  },
  {
    id: "2",
    author: "نورا سالم",
    content: "ما شاء الله، الطقس يبدو جميلاً جداً",
    timestamp: "منذ ساعتين",
    likes: 5,
    avatar: "/nora-profile.png",
  },
  {
    id: "3",
    author: "محمد العتيبي",
    content: "الرياض في أجمل حالاتها! استمتع بوقتك",
    timestamp: "منذ 3 ساعات",
    likes: 2,
    avatar: "/mohammed-otaibi-profile.png",
  },
]

export function CommentsList({ postId }: CommentsListProps) {
  const [comments] = useState<Comment[]>(mockComments)
  const [replyingTo, setReplyingTo] = useState<string | null>(null)
  const [replyText, setReplyText] = useState("")
  const [likedComments, setLikedComments] = useState<Set<string>>(new Set())

  const handleLikeComment = (commentId: string) => {
    setLikedComments((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(commentId)) {
        newSet.delete(commentId)
      } else {
        newSet.add(commentId)
      }
      return newSet
    })
  }

  const handleReply = (commentId: string) => {
    setReplyingTo(replyingTo === commentId ? null : commentId)
    setReplyText("")
  }

  const handleSubmitReply = (e: React.FormEvent, commentId: string) => {
    e.preventDefault()
    if (replyText.trim()) {
      console.log("Replying to comment:", commentId, "with:", replyText)
      setReplyText("")
      setReplyingTo(null)
    }
  }

  const CommentItem = ({ comment, isReply = false }: { comment: Comment; isReply?: boolean }) => (
    <div className={`flex gap-2 ${isReply ? "mr-8" : ""}`}>
      <img
        src={comment.avatar || "/placeholder.svg?height=32&width=32&query=user-avatar"}
        alt={comment.author}
        className="w-8 h-8 rounded-full object-cover flex-shrink-0"
      />
      <div className="flex-1">
        <div className="bg-muted rounded-2xl px-3 py-2">
          <h4 className="font-semibold text-sm">{comment.author}</h4>
          <p className="text-sm text-right">{comment.content}</p>
        </div>

        <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
          <span>{comment.timestamp}</span>
          <Button
            variant="ghost"
            size="sm"
            className={`h-auto p-0 text-xs ${likedComments.has(comment.id) ? "text-primary" : ""}`}
            onClick={() => handleLikeComment(comment.id)}
          >
            إعجاب ({comment.likes + (likedComments.has(comment.id) ? 1 : 0)})
          </Button>
          {!isReply && (
            <Button variant="ghost" size="sm" className="h-auto p-0 text-xs" onClick={() => handleReply(comment.id)}>
              رد
            </Button>
          )}
          <Button variant="ghost" size="sm" className="h-auto p-0">
            <MoreHorizontal className="w-3 h-3" />
          </Button>
        </div>

        {/* Replies */}
        {comment.replies && comment.replies.length > 0 && (
          <div className="mt-2 space-y-2">
            {comment.replies.map((reply) => (
              <CommentItem key={reply.id} comment={reply} isReply={true} />
            ))}
          </div>
        )}

        {/* Reply Form */}
        {replyingTo === comment.id && (
          <form onSubmit={(e) => handleSubmitReply(e, comment.id)} className="flex items-center gap-2 mt-2">
            <div className="w-6 h-6 bg-primary rounded-full flex-shrink-0"></div>
            <div className="flex-1 relative">
              <Input
                placeholder={`الرد على ${comment.author}...`}
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                className="pr-12 text-right text-sm"
                autoFocus
              />
              <Button
                type="submit"
                size="icon"
                variant="ghost"
                className="absolute left-2 top-1/2 transform -translate-y-1/2 w-6 h-6"
                disabled={!replyText.trim()}
              >
                <Send className="w-3 h-3" />
              </Button>
            </div>
          </form>
        )}
      </div>
    </div>
  )

  return (
    <div className="space-y-3">
      {comments.map((comment) => (
        <CommentItem key={comment.id} comment={comment} />
      ))}
    </div>
  )
}
