"use client"

import { Button } from "@/components/ui/button"
import { Home, Users, Bookmark, Calendar, Clock, ChevronDown } from "lucide-react"
import Link from "next/link"

export function Sidebar() {
  return (
    <aside className="w-80 p-4 hidden md:block">
      <div className="sticky top-20 space-y-2">
        <Link href="/feed">
          <Button variant="ghost" className="w-full justify-start gap-3 text-right">
            <Home className="w-5 h-5" />
            الصفحة الرئيسية
          </Button>
        </Link>
        <Link href="/friends">
          <Button variant="ghost" className="w-full justify-start gap-3 text-right">
            <Users className="w-5 h-5" />
            الأصدقاء
          </Button>
        </Link>
        <Button variant="ghost" className="w-full justify-start gap-3 text-right">
          <Bookmark className="w-5 h-5" />
          المحفوظات
        </Button>
        <Button variant="ghost" className="w-full justify-start gap-3 text-right">
          <Calendar className="w-5 h-5" />
          الأحداث
        </Button>
        <Button variant="ghost" className="w-full justify-start gap-3 text-right">
          <Clock className="w-5 h-5" />
          الذكريات
        </Button>

        <Button variant="ghost" className="w-full justify-start gap-3 text-right">
          <ChevronDown className="w-5 h-5" />
          عرض المزيد
        </Button>

        <div className="pt-4 border-t border-border">
          <h3 className="font-semibold mb-2 text-sm text-muted-foreground">اختصاراتك</h3>
          <div className="space-y-1">
            <Button variant="ghost" className="w-full justify-start gap-3 text-right">
              <div className="w-5 h-5 bg-primary rounded"></div>
              مجموعة الأصدقاء
            </Button>
            <Button variant="ghost" className="w-full justify-start gap-3 text-right">
              <div className="w-5 h-5 bg-secondary rounded"></div>
              صفحة العمل
            </Button>
          </div>
        </div>
      </div>
    </aside>
  )
}
