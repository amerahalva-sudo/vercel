"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Video, VideoOff, Mic, MicOff, Users, Heart, Share, Settings, X, Send, Eye } from "lucide-react"

interface LiveStreamViewerProps {
  streamId: string
  isOwner?: boolean
  onEndStream?: () => void
}

interface ChatMessage {
  id: string
  user: string
  message: string
  timestamp: string
  avatar?: string
}

const mockChatMessages: ChatMessage[] = [
  {
    id: "1",
    user: "أحمد محمد",
    message: "مرحباً! بث رائع",
    timestamp: "الآن",
    avatar: "/ahmed-profile.png",
  },
  {
    id: "2",
    user: "سارة أحمد",
    message: "شكراً لك على المحتوى المفيد",
    timestamp: "منذ دقيقة",
    avatar: "/sarah-profile.png",
  },
  {
    id: "3",
    user: "محمد العتيبي",
    message: "هل يمكنك إعادة الجزء الأخير؟",
    timestamp: "منذ دقيقتين",
    avatar: "/mohammed-otaibi-profile.png",
  },
]

export function LiveStreamViewer({ streamId, isOwner = false, onEndStream }: LiveStreamViewerProps) {
  const [isVideoOn, setIsVideoOn] = useState(true)
  const [isAudioOn, setIsAudioOn] = useState(true)
  const [viewerCount, setViewerCount] = useState(1247)
  const [likes, setLikes] = useState(89)
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(mockChatMessages)
  const [newMessage, setNewMessage] = useState("")
  const [isFullscreen, setIsFullscreen] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const chatEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [chatMessages])

  const sendMessage = () => {
    if (newMessage.trim()) {
      const message: ChatMessage = {
        id: Date.now().toString(),
        user: "أنت",
        message: newMessage,
        timestamp: "الآن",
      }
      setChatMessages([...chatMessages, message])
      setNewMessage("")
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault()
      sendMessage()
    }
  }

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen()
      setIsFullscreen(true)
    } else {
      document.exitFullscreen()
      setIsFullscreen(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black z-50 flex">
      {/* Main Video Area */}
      <div className="flex-1 relative">
        <div className="relative w-full h-full bg-black">
          <video ref={videoRef} autoPlay muted={!isAudioOn} playsInline className="w-full h-full object-contain" />

          {!isVideoOn && (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
              <VideoOff className="w-24 h-24 text-white" />
            </div>
          )}

          {/* Stream Info Overlay */}
          <div className="absolute top-4 left-4 right-4 flex items-start justify-between">
            <div className="flex items-center gap-3">
              <Badge variant="destructive" className="bg-red-600 text-white animate-pulse">
                <div className="w-2 h-2 bg-white rounded-full ml-1"></div>
                مباشر
              </Badge>
              <div className="flex items-center gap-2 bg-black/50 rounded-lg px-3 py-1">
                <Eye className="w-4 h-4 text-white" />
                <span className="text-white font-medium">{viewerCount.toLocaleString()}</span>
              </div>
            </div>

            <Button variant="ghost" size="icon" onClick={onEndStream} className="text-white hover:bg-white/20">
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Stream Controls (Owner Only) */}
          {isOwner && (
            <div className="absolute bottom-4 left-4 flex gap-2">
              <Button
                variant={isVideoOn ? "default" : "destructive"}
                size="icon"
                onClick={() => setIsVideoOn(!isVideoOn)}
              >
                {isVideoOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
              </Button>
              <Button
                variant={isAudioOn ? "default" : "destructive"}
                size="icon"
                onClick={() => setIsAudioOn(!isAudioOn)}
              >
                {isAudioOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
              </Button>
              <Button variant="outline" size="icon">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          )}

          {/* Viewer Actions */}
          {!isOwner && (
            <div className="absolute bottom-4 left-4 flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLikes(likes + 1)}
                className="bg-black/50 border-white/20 text-white hover:bg-white/20"
              >
                <Heart className="w-4 h-4 ml-1" />
                {likes}
              </Button>
              <Button variant="outline" size="sm" className="bg-black/50 border-white/20 text-white hover:bg-white/20">
                <Share className="w-4 h-4 ml-1" />
                مشاركة
              </Button>
            </div>
          )}

          {/* Stream Title */}
          <div className="absolute bottom-4 right-4 max-w-md">
            <div className="bg-black/50 rounded-lg p-3">
              <h3 className="text-white font-semibold text-lg">طبخ الكبسة الأردنية التقليدية</h3>
              <p className="text-white/80 text-sm">تعلم طريقة تحضير الكبسة الأصيلة خطوة بخطوة</p>
            </div>
          </div>
        </div>
      </div>

      {/* Live Chat Sidebar */}
      <div className="w-80 bg-card border-l border-border flex flex-col">
        <div className="p-4 border-b border-border">
          <h3 className="font-semibold flex items-center gap-2">
            <Users className="w-4 h-4" />
            الدردشة المباشرة ({viewerCount.toLocaleString()})
          </h3>
        </div>

        <ScrollArea className="flex-1 p-4">
          <div className="space-y-3">
            {chatMessages.map((message) => (
              <div key={message.id} className="flex items-start gap-2">
                <Avatar className="w-6 h-6">
                  <AvatarImage src={message.avatar || "/placeholder.svg"} alt={message.user} />
                  <AvatarFallback className="text-xs">{message.user.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">{message.user}</span>
                    <span className="text-xs text-muted-foreground">{message.timestamp}</span>
                  </div>
                  <p className="text-sm">{message.message}</p>
                </div>
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>
        </ScrollArea>

        <div className="p-4 border-t border-border">
          <div className="flex gap-2">
            <Input
              placeholder="اكتب رسالة..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              className="text-right"
            />
            <Button onClick={sendMessage} disabled={!newMessage.trim()}>
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
