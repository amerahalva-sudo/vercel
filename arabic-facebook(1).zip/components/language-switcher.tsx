"use client"

import { Button } from "@/components/ui/button"
import { Globe } from "lucide-react"
import { useRTL } from "@/components/rtl-provider"

export function LanguageSwitcher() {
  const { isRTL, toggleDirection } = useRTL()

  return (
    <Button variant="ghost" size="sm" onClick={toggleDirection} className="gap-2">
      <Globe className="w-4 h-4" />
      {isRTL ? "English" : "العربية"}
    </Button>
  )
}
