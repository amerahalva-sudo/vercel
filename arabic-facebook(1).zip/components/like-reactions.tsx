"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Heart, ThumbsUp, Laugh, Angry, Frown, Sunrise as Surprise } from "lucide-react"

interface LikeReactionsProps {
  onReaction: (reaction: string) => void
  currentReaction?: string
}

const reactions = [
  { id: "like", icon: ThumbsUp, label: "إعجاب", color: "text-blue-600" },
  { id: "love", icon: Heart, label: "حب", color: "text-red-500" },
  { id: "laugh", icon: Laugh, label: "ضحك", color: "text-yellow-500" },
  { id: "surprise", icon: Surprise, label: "تعجب", color: "text-orange-500" },
  { id: "sad", icon: Frown, label: "حزن", color: "text-blue-400" },
  { id: "angry", icon: Angry, label: "غضب", color: "text-red-600" },
]

export function LikeReactions({ onReaction, currentReaction }: LikeReactionsProps) {
  const [showReactions, setShowReactions] = useState(false)

  const handleReaction = (reactionId: string) => {
    onReaction(reactionId)
    setShowReactions(false)
  }

  const currentReactionData = reactions.find((r) => r.id === currentReaction)

  return (
    <div className="relative">
      <Button
        variant="ghost"
        size="sm"
        className={`gap-2 flex-1 ${currentReaction ? currentReactionData?.color : ""}`}
        onMouseEnter={() => setShowReactions(true)}
        onMouseLeave={() => setShowReactions(false)}
        onClick={() => handleReaction(currentReaction ? "" : "like")}
      >
        {currentReactionData ? (
          <currentReactionData.icon className="w-4 h-4 fill-current" />
        ) : (
          <ThumbsUp className="w-4 h-4" />
        )}
        {currentReactionData?.label || "إعجاب"}
      </Button>

      {showReactions && (
        <div
          className="absolute bottom-full left-0 mb-2 bg-card border border-border rounded-full p-2 shadow-lg flex gap-1 z-10"
          onMouseEnter={() => setShowReactions(true)}
          onMouseLeave={() => setShowReactions(false)}
        >
          {reactions.map((reaction) => (
            <Button
              key={reaction.id}
              variant="ghost"
              size="sm"
              className={`w-10 h-10 rounded-full hover:scale-125 transition-transform ${reaction.color}`}
              onClick={() => handleReaction(reaction.id)}
            >
              <reaction.icon className="w-5 h-5" />
            </Button>
          ))}
        </div>
      )}
    </div>
  )
}
