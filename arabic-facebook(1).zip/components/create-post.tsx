"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { ImageIcon, Smile, MapPin, Users, Calendar, Video, X, Play } from "lucide-react"
import { MediaUploader } from "@/components/media-uploader"

interface MediaFile {
  id: string
  type: "image" | "video"
  url: string
  file: File
  thumbnail?: string
}

export function CreatePost() {
  const [content, setContent] = useState("")
  const [isExpanded, setIsExpanded] = useState(false)
  const [mediaFiles, setMediaFiles] = useState<MediaFile[]>([])
  const [showMediaUploader, setShowMediaUploader] = useState(false)
  const [showLiveStreamSetup, setShowLiveStreamSetup] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const mediaUrls = mediaFiles.map((file) => file.url)
      const mediaType =
        mediaFiles.length > 0
          ? mediaFiles.every((f) => f.type === "image")
            ? "image"
            : mediaFiles.every((f) => f.type === "video")
              ? "video"
              : "mixed"
          : null

      const response = await fetch("/api/posts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content,
          media_urls: mediaUrls,
          media_type: mediaType,
          privacy: "public",
        }),
      })

      if (response.ok) {
        setContent("")
        setMediaFiles([])
        setIsExpanded(false)
        // Refresh the page or update the feed
        window.location.reload()
      } else {
        const error = await response.json()
        console.error("Error creating post:", error)
      }
    } catch (error) {
      console.error("Error creating post:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleMediaUpload = (files: MediaFile[]) => {
    setMediaFiles([...mediaFiles, ...files])
    setShowMediaUploader(false)
    setIsExpanded(true)
  }

  const removeMedia = (id: string) => {
    setMediaFiles(mediaFiles.filter((file) => file.id !== id))
  }

  const handleStartLiveStream = () => {
    setShowLiveStreamSetup(false)
    // Navigate to live streaming page
    window.location.href = "/live"
  }

  return (
    <Card>
      <CardContent className="p-4">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-primary rounded-full flex-shrink-0"></div>
            <Textarea
              placeholder="بماذا تفكر؟"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              onFocus={() => setIsExpanded(true)}
              className={`min-h-[${isExpanded ? "100" : "50"}px] resize-none border-none shadow-none text-right transition-all`}
            />
          </div>

          {mediaFiles.length > 0 && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {mediaFiles.map((media) => (
                  <div key={media.id} className="relative group">
                    <div className="relative rounded-lg overflow-hidden bg-muted aspect-square">
                      {media.type === "image" ? (
                        <img
                          src={media.url || "/placeholder.svg"}
                          alt="معاينة الصورة"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="relative w-full h-full">
                          <video src={media.url} className="w-full h-full object-cover" muted />
                          <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                            <Play className="w-8 h-8 text-white" />
                          </div>
                        </div>
                      )}
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 left-2 w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => removeMedia(media.id)}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {isExpanded && (
            <div className="space-y-3 pt-2 border-t border-border">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">إضافة إلى منشورك</span>
                <div className="flex items-center gap-1">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="gap-2 text-green-600"
                    onClick={() => setShowMediaUploader(true)}
                  >
                    <ImageIcon className="w-4 h-4" />
                    صورة/فيديو
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="gap-2 text-red-600"
                    onClick={() => setShowLiveStreamSetup(true)}
                  >
                    <Video className="w-4 h-4" />
                    بث مباشر
                  </Button>
                  <Button type="button" variant="ghost" size="sm" className="gap-2 text-yellow-600">
                    <Smile className="w-4 h-4" />
                    مشاعر
                  </Button>
                  <Button type="button" variant="ghost" size="sm" className="gap-2 text-red-600">
                    <MapPin className="w-4 h-4" />
                    موقع
                  </Button>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Button type="button" variant="ghost" size="sm" className="gap-2">
                  <Users className="w-4 h-4" />
                  وسم أصدقاء
                </Button>
                <Button type="button" variant="ghost" size="sm" className="gap-2">
                  <Calendar className="w-4 h-4" />
                  حدث
                </Button>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between pt-2 border-t border-border">
            <div className="flex items-center gap-2">
              {!isExpanded && (
                <>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="gap-2"
                    onClick={() => setShowMediaUploader(true)}
                  >
                    <ImageIcon className="w-4 h-4 text-green-600" />
                    صورة/فيديو
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="gap-2"
                    onClick={() => setShowLiveStreamSetup(true)}
                  >
                    <Video className="w-4 h-4 text-red-600" />
                    بث مباشر
                  </Button>
                  <Button type="button" variant="ghost" size="sm" className="gap-2">
                    <Smile className="w-4 h-4 text-yellow-600" />
                    مشاعر
                  </Button>
                  <Button type="button" variant="ghost" size="sm" className="gap-2">
                    <MapPin className="w-4 h-4 text-red-600" />
                    موقع
                  </Button>
                </>
              )}
            </div>

            <Button type="submit" disabled={(!content.trim() && mediaFiles.length === 0) || isLoading}>
              {isLoading ? "جاري النشر..." : "نشر"}
            </Button>
          </div>
        </form>

        {showMediaUploader && (
          <MediaUploader onUpload={handleMediaUpload} onClose={() => setShowMediaUploader(false)} />
        )}

        {showLiveStreamSetup && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-card rounded-lg p-6 max-w-md w-full">
              <div className="text-center space-y-4">
                <Video className="w-16 h-16 mx-auto text-red-600" />
                <h3 className="text-xl font-bold">بدء بث مباشر</h3>
                <p className="text-muted-foreground">هل تريد بدء بث مباشر الآن؟ سيتم نقلك إلى صفحة إعداد البث.</p>
                <div className="flex gap-3">
                  <Button onClick={handleStartLiveStream} className="flex-1 bg-red-600 hover:bg-red-700">
                    نعم، ابدأ البث
                  </Button>
                  <Button variant="outline" onClick={() => setShowLiveStreamSetup(false)} className="flex-1">
                    إلغاء
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
