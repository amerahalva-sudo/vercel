export function Footer() {
  return (
    <footer className="bg-card border-t border-border py-4 mt-auto">
      <div className="max-w-7xl mx-auto px-4 text-center">
        
      </div>
    </footer>
  )
}
