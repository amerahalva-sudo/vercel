"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Eye, Users, Play } from "lucide-react"

interface LiveStream {
  id: string
  title: string
  streamer: string
  avatar: string
  thumbnail: string
  viewers: number
  category: string
  duration: string
  isLive: boolean
}

const mockLiveStreams: LiveStream[] = [
  {
    id: "1",
    title: "طبخ المنسف الأردني الأصيل",
    streamer: "أم محمد",
    avatar: "/serene-woman-profile.png",
    thumbnail: "/traditional-jordanian-cooking.png",
    viewers: 1247,
    category: "الطبخ",
    duration: "45 دقيقة",
    isLive: true,
  },
  {
    id: "2",
    title: "جولة في البتراء الوردية",
    streamer: "أحمد السائح",
    avatar: "/ahmed-profile.png",
    thumbnail: "/petra-tour.png",
    viewers: 892,
    category: "السفر",
    duration: "1 ساعة 20 دقيقة",
    isLive: true,
  },
  {
    id: "3",
    title: "تعلم البرمجة بـ React",
    streamer: "محمد المطور",
    avatar: "/mohammed-profile.png",
    thumbnail: "/programming-tutorial.png",
    viewers: 567,
    category: "التعليم",
    duration: "2 ساعة",
    isLive: true,
  },
  {
    id: "4",
    title: "مباراة كرة القدم المحلية",
    streamer: "قناة الرياضة",
    avatar: "/sports-channel.png",
    thumbnail: "/football-match.png",
    viewers: 3421,
    category: "الرياضة",
    duration: "1 ساعة 30 دقيقة",
    isLive: true,
  },
]

interface LiveStreamsGridProps {
  filter: "all" | "following"
}

export function LiveStreamsGrid({ filter }: LiveStreamsGridProps) {
  const [selectedStream, setSelectedStream] = useState<string | null>(null)

  const filteredStreams = mockLiveStreams.filter((stream) => {
    if (filter === "following") {
      // In a real app, this would filter based on followed streamers
      return stream.viewers > 1000
    }
    return true
  })

  const handleStreamClick = (streamId: string) => {
    setSelectedStream(streamId)
    // In a real app, this would navigate to the stream viewer
    console.log("Opening stream:", streamId)
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {filteredStreams.map((stream) => (
        <Card key={stream.id} className="group hover:shadow-lg transition-shadow cursor-pointer">
          <CardContent className="p-0">
            <div className="relative aspect-video rounded-t-lg overflow-hidden bg-muted">
              <img
                src={stream.thumbnail || "/placeholder.svg"}
                alt={stream.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />

              {/* Live Badge */}
              {stream.isLive && (
                <Badge variant="destructive" className="absolute top-2 right-2 bg-red-600 text-white animate-pulse">
                  <div className="w-2 h-2 bg-white rounded-full ml-1"></div>
                  مباشر
                </Badge>
              )}

              {/* Viewer Count */}
              <div className="absolute top-2 left-2 bg-black/50 rounded px-2 py-1 flex items-center gap-1">
                <Eye className="w-3 h-3 text-white" />
                <span className="text-white text-xs font-medium">{stream.viewers.toLocaleString()}</span>
              </div>

              {/* Play Button Overlay */}
              <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Button
                  size="icon"
                  className="bg-white/20 hover:bg-white/30 text-white border-white/20"
                  onClick={() => handleStreamClick(stream.id)}
                >
                  <Play className="w-6 h-6" />
                </Button>
              </div>

              {/* Duration */}
              <div className="absolute bottom-2 left-2 bg-black/50 rounded px-2 py-1">
                <span className="text-white text-xs">{stream.duration}</span>
              </div>
            </div>

            <div className="p-4">
              <div className="flex items-start gap-3">
                <Avatar className="w-10 h-10 flex-shrink-0">
                  <AvatarImage src={stream.avatar || "/placeholder.svg"} alt={stream.streamer} />
                  <AvatarFallback>{stream.streamer.charAt(0)}</AvatarFallback>
                </Avatar>

                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-sm line-clamp-2 mb-1">{stream.title}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{stream.streamer}</p>

                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-xs">
                      {stream.category}
                    </Badge>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Users className="w-3 h-3" />
                      {stream.viewers.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
