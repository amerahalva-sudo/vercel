"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Video, VideoOff, Mic, MicOff, Settings, Users, Globe, Lock } from "lucide-react"

interface LiveStreamSetupProps {
  onStartStream: () => void
}

export function LiveStreamSetup({ onStartStream }: LiveStreamSetupProps) {
  const [streamData, setStreamData] = useState({
    title: "",
    description: "",
    category: "",
    privacy: "public",
    allowComments: true,
    allowSharing: true,
  })
  const [isVideoOn, setIsVideoOn] = useState(true)
  const [isAudioOn, setIsAudioOn] = useState(true)
  const [isPreviewReady, setIsPreviewReady] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    const setupCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true,
        })
        if (videoRef.current) {
          videoRef.current.srcObject = stream
          setIsPreviewReady(true)
        }
      } catch (error) {
        console.error("Error accessing camera:", error)
      }
    }

    setupCamera()

    return () => {
      if (videoRef.current?.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream
        stream.getTracks().forEach((track) => track.stop())
      }
    }
  }, [])

  const toggleVideo = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream
      const videoTrack = stream.getVideoTracks()[0]
      if (videoTrack) {
        videoTrack.enabled = !isVideoOn
        setIsVideoOn(!isVideoOn)
      }
    }
  }

  const toggleAudio = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream
      const audioTrack = stream.getAudioTracks()[0]
      if (audioTrack) {
        audioTrack.enabled = !isAudioOn
        setIsAudioOn(!isAudioOn)
      }
    }
  }

  const handleStartStream = () => {
    if (streamData.title.trim()) {
      console.log("Starting stream with data:", streamData)
      onStartStream()
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Stream Preview */}
      <Card>
        <CardHeader>
          <CardTitle>معاينة البث</CardTitle>
          <CardDescription>تأكد من إعدادات الكاميرا والصوت قبل البدء</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
              <video ref={videoRef} autoPlay muted playsInline className="w-full h-full object-cover" />
              {!isVideoOn && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
                  <VideoOff className="w-12 h-12 text-white" />
                </div>
              )}
              <div className="absolute bottom-4 left-4 flex gap-2">
                <Button variant={isVideoOn ? "default" : "destructive"} size="icon" onClick={toggleVideo}>
                  {isVideoOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
                </Button>
                <Button variant={isAudioOn ? "default" : "destructive"} size="icon" onClick={toggleAudio}>
                  {isAudioOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                </Button>
                <Button variant="outline" size="icon">
                  <Settings className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="text-center">
              <p className="text-sm text-muted-foreground">
                {isPreviewReady ? "الكاميرا جاهزة للبث" : "جاري تحضير الكاميرا..."}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stream Settings */}
      <Card>
        <CardHeader>
          <CardTitle>إعدادات البث</CardTitle>
          <CardDescription>اضبط تفاصيل البث المباشر</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">عنوان البث</Label>
              <Input
                id="title"
                placeholder="اكتب عنوان جذاب لبثك المباشر"
                value={streamData.title}
                onChange={(e) => setStreamData({ ...streamData, title: e.target.value })}
                className="text-right"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">وصف البث</Label>
              <Textarea
                id="description"
                placeholder="اكتب وصف مختصر عن محتوى البث"
                value={streamData.description}
                onChange={(e) => setStreamData({ ...streamData, description: e.target.value })}
                className="text-right min-h-[80px]"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">فئة البث</Label>
              <Select
                value={streamData.category}
                onValueChange={(value) => setStreamData({ ...streamData, category: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر فئة البث" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gaming">الألعاب</SelectItem>
                  <SelectItem value="cooking">الطبخ</SelectItem>
                  <SelectItem value="education">التعليم</SelectItem>
                  <SelectItem value="music">الموسيقى</SelectItem>
                  <SelectItem value="sports">الرياضة</SelectItem>
                  <SelectItem value="travel">السفر</SelectItem>
                  <SelectItem value="lifestyle">نمط الحياة</SelectItem>
                  <SelectItem value="other">أخرى</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="privacy">خصوصية البث</Label>
              <Select
                value={streamData.privacy}
                onValueChange={(value) => setStreamData({ ...streamData, privacy: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="public">
                    <div className="flex items-center gap-2">
                      <Globe className="w-4 h-4" />
                      عام - يمكن لأي شخص المشاهدة
                    </div>
                  </SelectItem>
                  <SelectItem value="friends">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      الأصدقاء فقط
                    </div>
                  </SelectItem>
                  <SelectItem value="private">
                    <div className="flex items-center gap-2">
                      <Lock className="w-4 h-4" />
                      خاص - بدعوة فقط
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-4 pt-4 border-t border-border">
              <div className="flex items-center justify-between">
                <Label htmlFor="comments">السماح بالتعليقات</Label>
                <Switch
                  id="comments"
                  checked={streamData.allowComments}
                  onCheckedChange={(checked) => setStreamData({ ...streamData, allowComments: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="sharing">السماح بالمشاركة</Label>
                <Switch
                  id="sharing"
                  checked={streamData.allowSharing}
                  onCheckedChange={(checked) => setStreamData({ ...streamData, allowSharing: checked })}
                />
              </div>
            </div>

            <Button
              onClick={handleStartStream}
              disabled={!streamData.title.trim() || !isPreviewReady}
              className="w-full bg-red-600 hover:bg-red-700 text-white"
            >
              <Video className="w-4 h-4 ml-2" />
              بدء البث المباشر
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
