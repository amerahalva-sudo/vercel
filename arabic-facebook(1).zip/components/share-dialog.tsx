"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Copy, Facebook, Twitter, MessageCircle, Mail } from "lucide-react"

interface Post {
  id: string
  author: string
  content: string
  timestamp: string
  likes: number
  comments: number
  shares: number
  image?: string
  avatar?: string
}

interface ShareDialogProps {
  post: Post
  onClose: () => void
}

export function ShareDialog({ post, onClose }: ShareDialogProps) {
  const [shareText, setShareText] = useState("")
  const [privacy, setPrivacy] = useState("public")
  const [copied, setCopied] = useState(false)

  const postUrl = `https://fais-urduni.com/post/${post.id}`

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(postUrl)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("Failed to copy link:", err)
    }
  }

  const handleShare = (platform: string) => {
    const text = encodeURIComponent(`${shareText || post.content} - ${postUrl}`)
    const urls = {
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(postUrl)}`,
      twitter: `https://twitter.com/intent/tweet?text=${text}`,
      whatsapp: `https://wa.me/?text=${text}`,
      telegram: `https://t.me/share/url?url=${encodeURIComponent(postUrl)}&text=${encodeURIComponent(shareText || post.content)}`,
      email: `mailto:?subject=${encodeURIComponent("شاهد هذا المنشور من فيس أردني")}&body=${text}`,
    }

    if (urls[platform as keyof typeof urls]) {
      window.open(urls[platform as keyof typeof urls], "_blank", "width=600,height=400")
    }
  }

  const handleDirectShare = () => {
    console.log("Sharing post with text:", shareText)
    onClose()
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-right">مشاركة المنشور</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Original Post Preview */}
          <div className="bg-muted p-3 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <img
                src={post.avatar || "/placeholder.svg?height=32&width=32&query=user-avatar"}
                alt={post.author}
                className="w-8 h-8 rounded-full"
              />
              <div>
                <p className="font-semibold text-sm">{post.author}</p>
                <p className="text-xs text-muted-foreground">{post.timestamp}</p>
              </div>
            </div>
            <p className="text-sm text-right line-clamp-3">{post.content}</p>
            {post.image && (
              <img
                src={post.image || "/placeholder.svg"}
                alt="Post"
                className="w-full h-20 object-cover rounded mt-2"
              />
            )}
          </div>

          {/* Share Text */}
          <div>
            <Textarea
              placeholder="أضف تعليقاً على المشاركة..."
              value={shareText}
              onChange={(e) => setShareText(e.target.value)}
              className="text-right resize-none"
              rows={3}
            />
          </div>

          {/* Privacy Settings */}
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">مشاركة مع:</span>
            <select
              value={privacy}
              onChange={(e) => setPrivacy(e.target.value)}
              className="text-sm border rounded px-2 py-1"
            >
              <option value="public">الجميع</option>
              <option value="friends">الأصدقاء فقط</option>
              <option value="private">أنا فقط</option>
            </select>
          </div>

          {/* Share Options */}
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" size="sm" onClick={() => handleShare("facebook")} className="gap-2">
              <Facebook className="w-4 h-4 text-blue-600" />
              فيسبوك
            </Button>
            <Button variant="outline" size="sm" onClick={() => handleShare("twitter")} className="gap-2">
              <Twitter className="w-4 h-4 text-blue-400" />
              تويتر
            </Button>
            <Button variant="outline" size="sm" onClick={() => handleShare("whatsapp")} className="gap-2">
              <MessageCircle className="w-4 h-4 text-green-600" />
              واتساب
            </Button>
            <Button variant="outline" size="sm" onClick={() => handleShare("email")} className="gap-2">
              <Mail className="w-4 h-4" />
              إيميل
            </Button>
          </div>

          {/* Copy Link */}
          <div className="flex items-center gap-2">
            <Input value={postUrl} readOnly className="text-left text-sm" />
            <Button variant="outline" size="sm" onClick={handleCopyLink} className="gap-1 bg-transparent">
              <Copy className="w-4 h-4" />
              {copied ? "تم النسخ!" : "نسخ"}
            </Button>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 pt-2">
            <Button onClick={handleDirectShare} className="flex-1">
              مشاركة الآن
            </Button>
            <Button variant="outline" onClick={onClose} className="flex-1 bg-transparent">
              إلغاء
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
