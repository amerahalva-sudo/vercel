"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

const stories = [
  {
    id: "1",
    author: "قصتك",
    image: "/your-story.png",
    isOwn: true,
  },
  {
    id: "2",
    author: "أحمد محمد",
    image: "/ahmed-story.png",
    isOwn: false,
  },
  {
    id: "3",
    author: "فاطمة علي",
    image: "/fatima-story.png",
    isOwn: false,
  },
  {
    id: "4",
    author: "محمد حسن",
    image: "/mohammed-story.png",
    isOwn: false,
  },
  {
    id: "5",
    author: "سارة أحمد",
    image: "/sarah-story.png",
    isOwn: false,
  },
]

export function StoriesSection() {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex gap-3 overflow-x-auto pb-2">
          {stories.map((story) => (
            <div key={story.id} className="flex-shrink-0">
              <div className="relative w-20 h-32 rounded-lg overflow-hidden cursor-pointer group">
                <img
                  src={story.image || "/placeholder.svg"}
                  alt={story.author}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>

                {story.isOwn ? (
                  <div className="absolute top-2 left-1/2 transform -translate-x-1/2">
                    <Button size="icon" className="w-8 h-8 rounded-full">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="absolute top-2 left-2">
                    <div className="w-8 h-8 bg-primary rounded-full border-2 border-white"></div>
                  </div>
                )}

                <div className="absolute bottom-2 left-2 right-2">
                  <p className="text-white text-xs font-medium text-center leading-tight">{story.author}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
