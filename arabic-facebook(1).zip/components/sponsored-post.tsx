"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Heart, MessageCircle, Share, ExternalLink } from "lucide-react"

interface SponsoredPostProps {
  ad: {
    id: string
    title: string
    description: string
    image?: string
    avatar: string
    sponsor: string
    ctaText: string
    ctaLink: string
  }
}

export function SponsoredPost({ ad }: SponsoredPostProps) {
  return (
    <Card className="border-l-4 border-l-primary">
      <CardContent className="p-6">
        <div className="flex items-start gap-3 mb-4">
          <Avatar className="w-10 h-10">
            <AvatarImage src={ad.avatar || "/placeholder.svg"} alt={ad.sponsor} />
            <AvatarFallback>{ad.sponsor.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold">{ad.sponsor}</h3>
              <Badge variant="secondary" className="text-xs">
                إعلان مدفوع
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground">منذ ساعتين</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <h4 className="font-semibold text-lg mb-2">{ad.title}</h4>
            <p className="text-muted-foreground">{ad.description}</p>
          </div>

          {ad.image && (
            <div className="rounded-lg overflow-hidden">
              <img src={ad.image || "/placeholder.svg"} alt={ad.title} className="w-full h-64 object-cover" />
            </div>
          )}

          <Button className="w-full bg-primary hover:bg-primary/90">
            <ExternalLink className="w-4 h-4 ml-2" />
            {ad.ctaText}
          </Button>

          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary">
                <Heart className="w-4 h-4 ml-1" />
                إعجاب
              </Button>
              <Button variant="ghost" size="sm" className="text-muted-foreground">
                <MessageCircle className="w-4 h-4 ml-1" />
                تعليق
              </Button>
              <Button variant="ghost" size="sm" className="text-muted-foreground">
                <Share className="w-4 h-4 ml-1" />
                مشاركة
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
