"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Play, Download, Share, MoreHorizontal, Eye } from "lucide-react"

interface MediaItem {
  id: string
  type: "image" | "video"
  url: string
  thumbnail?: string
  title: string
  size: string
  uploadDate: string
  views: number
}

const mockMediaItems: MediaItem[] = [
  {
    id: "1",
    type: "image",
    url: "/beautiful-day-in-riyadh.png",
    title: "يوم جميل في الرياض",
    size: "2.4 MB",
    uploadDate: "منذ يومين",
    views: 156,
  },
  {
    id: "2",
    type: "video",
    url: "/cooking-video.mp4",
    thumbnail: "/traditional-chicken-kabsa-dish.png",
    title: "طبخ الكبسة التقليدية",
    size: "45.2 MB",
    uploadDate: "منذ أسبوع",
    views: 892,
  },
  {
    id: "3",
    type: "image",
    url: "/king-abdulaziz-museum-visit.png",
    title: "زيارة متحف الملك عبدالعزيز",
    size: "3.1 MB",
    uploadDate: "منذ أسبوعين",
    views: 234,
  },
  {
    id: "4",
    type: "video",
    url: "/tech-conference.mp4",
    thumbnail: "/saudi-tech-conference-2024.png",
    title: "مؤتمر التقنية السعودي 2024",
    size: "78.5 MB",
    uploadDate: "منذ شهر",
    views: 1205,
  },
]

interface MediaGalleryProps {
  viewMode: "grid" | "list"
  searchQuery: string
  filter: "all" | "images" | "videos" | "recent"
}

export function MediaGallery({ viewMode, searchQuery, filter }: MediaGalleryProps) {
  const [selectedItems, setSelectedItems] = useState<string[]>([])

  const filteredItems = mockMediaItems.filter((item) => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesFilter =
      filter === "all" ||
      (filter === "images" && item.type === "image") ||
      (filter === "videos" && item.type === "video") ||
      filter === "recent"

    return matchesSearch && matchesFilter
  })

  const toggleSelection = (id: string) => {
    setSelectedItems((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]))
  }

  if (viewMode === "list") {
    return (
      <div className="space-y-2">
        {filteredItems.map((item) => (
          <Card key={item.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                  {item.type === "image" ? (
                    <img src={item.url || "/placeholder.svg"} alt={item.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="relative w-full h-full">
                      <img
                        src={item.thumbnail || "/placeholder.svg"}
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                        <Play className="w-4 h-4 text-white" />
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold truncate">{item.title}</h3>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <Badge variant="outline">{item.type === "image" ? "صورة" : "فيديو"}</Badge>
                    <span>{item.size}</span>
                    <span>{item.uploadDate}</span>
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      {item.views}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon">
                    <Download className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Share className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
      {filteredItems.map((item) => (
        <Card key={item.id} className="group hover:shadow-lg transition-shadow">
          <CardContent className="p-0">
            <div className="relative aspect-square rounded-t-lg overflow-hidden bg-muted">
              {item.type === "image" ? (
                <img
                  src={item.url || "/placeholder.svg"}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
              ) : (
                <div className="relative w-full h-full">
                  <img
                    src={item.thumbnail || "/placeholder.svg"}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                    <Play className="w-8 h-8 text-white" />
                  </div>
                </div>
              )}

              {/* Overlay Actions */}
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <Button variant="secondary" size="icon">
                  <Eye className="w-4 h-4" />
                </Button>
                <Button variant="secondary" size="icon">
                  <Download className="w-4 h-4" />
                </Button>
                <Button variant="secondary" size="icon">
                  <Share className="w-4 h-4" />
                </Button>
              </div>

              <Badge variant="secondary" className="absolute top-2 right-2">
                {item.type === "image" ? "صورة" : "فيديو"}
              </Badge>
            </div>

            <div className="p-3">
              <h3 className="font-semibold text-sm truncate mb-1">{item.title}</h3>
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>{item.size}</span>
                <span className="flex items-center gap-1">
                  <Eye className="w-3 h-3" />
                  {item.views}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{item.uploadDate}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
