"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { PostCard } from "@/components/post-card"
import { Camera, MapPin, Calendar, Users, Edit, MessageCircle, UserPlus } from "lucide-react"

const userPosts = [
  {
    id: "1",
    author: "أحمد محمد",
    content: "شكراً لجميع الأصدقاء على التهاني بمناسبة عيد ميلادي! يوم رائع مع الأحباب.",
    timestamp: "منذ يوم",
    likes: 45,
    comments: 12,
    shares: 3,
    image: "/birthday-celebration.png",
  },
  {
    id: "2",
    author: "أحمد محمد",
    content: "رحلة جميلة إلى جدة التاريخية. المكان مليء بالتاريخ والثقافة العريقة.",
    timestamp: "منذ 3 أيام",
    likes: 28,
    comments: 8,
    shares: 5,
    image: "/historic-jeddah-trip.png",
  },
]

export function UserProfile() {
  const [isOwnProfile] = useState(true) // In real app, this would be determined by comparing current user with profile user

  return (
    <div className="space-y-6">
      {/* Cover Photo and Profile Picture */}
      <Card>
        <div className="relative">
          <div className="h-64 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-t-lg"></div>
          <Button variant="secondary" size="sm" className="absolute bottom-4 left-4 gap-2">
            <Camera className="w-4 h-4" />
            تغيير الغلاف
          </Button>

          <div className="absolute -bottom-16 right-8">
            <div className="relative">
              <div className="w-32 h-32 bg-primary rounded-full border-4 border-background"></div>
              <Button variant="secondary" size="icon" className="absolute bottom-2 left-2 w-8 h-8 rounded-full">
                <Camera className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        <CardContent className="pt-20 pb-6">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold">أحمد محمد</h1>
              <p className="text-muted-foreground">مطور برمجيات في الرياض</p>
              <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Users className="w-4 h-4" />
                  <span>1,234 صديق</span>
                </div>
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  <span>الرياض، السعودية</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>انضم في يناير 2020</span>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              {isOwnProfile ? (
                <>
                  <Button variant="outline" className="gap-2 bg-transparent">
                    <Edit className="w-4 h-4" />
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-square-pen w-4 h-4"><path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.375 2.625a2.121 2.121 0 1 1 3 3L12 15l-4 1 1-4Z"></path></svg>تعديل الملف الشخصي
                  </Button>
                  <Button className="gap-2">إضافة إلى القصة</Button>
                </>
              ) : (
                <>
                  <Button className="gap-2">
                    <UserPlus className="w-4 h-4" />
                    إضافة صديق
                  </Button>
                  <Button variant="outline" className="gap-2 bg-transparent">
                    <MessageCircle className="w-4 h-4" />
                    رسالة
                  </Button>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Profile Navigation */}
      <Tabs defaultValue="posts" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="posts">المنشورات</TabsTrigger>
          <TabsTrigger value="about">حول</TabsTrigger>
          <TabsTrigger value="friends">الأصدقاء</TabsTrigger>
          <TabsTrigger value="photos">الصور</TabsTrigger>
        </TabsList>

        <div className="mt-6">
          <TabsContent value="posts" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="md:col-span-1 space-y-4">
                <Card>
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-3">المعلومات</h3>
                    <div className="space-y-3 text-sm">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-muted-foreground" />
                        <span>يعيش في الرياض</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-muted-foreground" />
                        <span>من مواليد 15 مارس 1990</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-muted-foreground" />
                        <span>متزوج</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-3">الأصدقاء</h3>
                    <p className="text-sm text-muted-foreground mb-3">1,234 صديق</p>
                    <div className="grid grid-cols-3 gap-2">
                      {[1, 2, 3, 4, 5, 6].map((i) => (
                        <div key={i} className="aspect-square bg-secondary rounded-lg"></div>
                      ))}
                    </div>
                    <Button variant="outline" className="w-full mt-3 bg-transparent">
                      عرض جميع الأصدقاء
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div className="md:col-span-2 space-y-6">
                {userPosts.map((post) => (
                  <PostCard key={post.id} post={post} />
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="about" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">العمل والتعليم</h3>
                  <div className="space-y-4">
                    <div>
                      <p className="font-medium">مطور برمجيات</p>
                      <p className="text-sm text-muted-foreground">شركة التقنية المتقدمة</p>
                      <p className="text-xs text-muted-foreground">2020 - الآن</p>
                    </div>
                    <div>
                      <p className="font-medium">بكالوريوس علوم الحاسب</p>
                      <p className="text-sm text-muted-foreground">جامعة الملك سعود</p>
                      <p className="text-xs text-muted-foreground">2016 - 2020</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">الأماكن التي عاش فيها</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="font-medium">الرياض، السعودية</p>
                        <p className="text-xs text-muted-foreground">المدينة الحالية</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="font-medium">جدة، السعودية</p>
                        <p className="text-xs text-muted-foreground">مسقط الرأس</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">معلومات الاتصال</h3>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-muted-foreground">البريد الإلكتروني</p>
                      <p className="font-medium">ahmed.mohamed@email.com</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">رقم الهاتف</p>
                      <p className="font-medium">+966 50 123 4567</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">الاهتمامات</h3>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary">البرمجة</Badge>
                    <Badge variant="secondary">التصوير</Badge>
                    <Badge variant="secondary">السفر</Badge>
                    <Badge variant="secondary">القراءة</Badge>
                    <Badge variant="secondary">كرة القدم</Badge>
                    <Badge variant="secondary">الطبخ</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="friends" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">الأصدقاء (1,234)</h2>
              <Button variant="outline">إدارة قائمة الأصدقاء</Button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {Array.from({ length: 12 }).map((_, i) => (
                <Card key={i} className="overflow-hidden">
                  <div className="aspect-square bg-primary"></div>
                  <CardContent className="p-3">
                    <p className="font-medium text-sm">صديق {i + 1}</p>
                    <p className="text-xs text-muted-foreground">5 أصدقاء مشتركين</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="photos" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">الصور</h2>
              <Button variant="outline">إضافة صور</Button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
              {Array.from({ length: 18 }).map((_, i) => (
                <div key={i} className="aspect-square bg-secondary rounded-lg"></div>
              ))}
            </div>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}
