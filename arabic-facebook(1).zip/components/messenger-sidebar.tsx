"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Search, Edit } from "lucide-react"
import Image from "next/image"

interface Chat {
  id: string
  name: string
  avatar: string
  lastMessage: string
  timestamp: string
  unread: number
  online: boolean
}

const mockChats: Chat[] = [
  {
    id: "ahmed-123",
    name: "أحمد محمد",
    avatar: "/ahmed-profile.png",
    lastMessage: "كيف الحال؟ شو أخبارك اليوم؟",
    timestamp: "منذ 5 دقائق",
    unread: 2,
    online: true,
  },
  {
    id: "sara-456",
    name: "سارة أحمد",
    avatar: "/sarah-profile.png",
    lastMessage: "شكراً لك على المساعدة",
    timestamp: "منذ ساعة",
    unread: 0,
    online: true,
  },
  {
    id: "mohammed-789",
    name: "محمد العتيبي",
    avatar: "/mohammed-otaibi-profile.png",
    lastMessage: "هل ستحضر الاجتماع غداً؟",
    timestamp: "منذ 3 ساعات",
    unread: 1,
    online: false,
  },
  {
    id: "layla-101",
    name: "ليلى خالد",
    avatar: "/layla-profile.png",
    lastMessage: "تم إرسال الملفات",
    timestamp: "أمس",
    unread: 0,
    online: false,
  },
]

interface MessengerSidebarProps {
  selectedChat: string | null
  onSelectChat: (chatId: string) => void
}

export function MessengerSidebar({ selectedChat, onSelectChat }: MessengerSidebarProps) {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredChats = mockChats.filter((chat) => chat.name.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <div className="w-80 border-l border-border bg-card h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Image src="/messenger-logo.png" alt="مسنجر فيس اردني" width={24} height={24} className="rounded" />
            <h2 className="text-xl font-bold">المحادثات</h2>
          </div>
          <Button size="icon" variant="ghost">
            <Edit className="w-4 h-4" />
          </Button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="البحث في المحادثات"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10 text-right"
          />
        </div>
      </div>

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto">
        {filteredChats.map((chat) => (
          <div
            key={chat.id}
            onClick={() => onSelectChat(chat.id)}
            className={`p-4 border-b border-border cursor-pointer hover:bg-muted/50 transition-colors ${
              selectedChat === chat.id ? "bg-primary/10" : ""
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="relative">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={chat.avatar || "/placeholder.svg"} alt={chat.name} />
                  <AvatarFallback>{chat.name.charAt(0)}</AvatarFallback>
                </Avatar>
                {chat.online && (
                  <div className="absolute -bottom-1 -left-1 w-4 h-4 bg-green-500 border-2 border-background rounded-full"></div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="font-semibold text-sm truncate">{chat.name}</h3>
                  <span className="text-xs text-muted-foreground">{chat.timestamp}</span>
                </div>
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground truncate">{chat.lastMessage}</p>
                  {chat.unread > 0 && (
                    <Badge variant="default" className="bg-primary text-primary-foreground text-xs">
                      {chat.unread}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
