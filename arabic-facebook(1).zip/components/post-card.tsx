"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Heart, MessageCircle, Share, MoreHorizontal, ThumbsUp, Send, Smile, Bookmark } from "lucide-react"
import { CommentsList } from "@/components/comments-list"
import { LikeReactions } from "@/components/like-reactions"
import { ShareDialog } from "@/components/share-dialog"

interface Post {
  id: string
  author: string
  content: string
  timestamp: string
  likes: number
  comments: number
  shares: number
  image?: string
  avatar?: string
}

interface PostCardProps {
  post: Post
}

export function PostCard({ post }: PostCardProps) {
  const [liked, setLiked] = useState(false)
  const [likesCount, setLikesCount] = useState(post.likes)
  const [showComments, setShowComments] = useState(false)
  const [newComment, setNewComment] = useState("")
  const [commentsCount, setCommentsCount] = useState(post.comments)
  const [showReactions, setShowReactions] = useState(false)
  const [showShareDialog, setShowShareDialog] = useState(false)
  const [saved, setSaved] = useState(false)
  const [currentReaction, setCurrentReaction] = useState<string | null>(null)

  const handleLike = () => {
    setLiked(!liked)
    setLikesCount((prev) => (liked ? prev - 1 : prev + 1))
    if (!liked) {
      setCurrentReaction("like")
    } else {
      setCurrentReaction(null)
    }
  }

  const handleReaction = (reaction: string) => {
    if (currentReaction !== reaction) {
      if (!currentReaction) {
        setLikesCount((prev) => prev + 1)
      }
      setCurrentReaction(reaction)
      setLiked(true)
    } else {
      setCurrentReaction(null)
      setLiked(false)
      setLikesCount((prev) => prev - 1)
    }
    setShowReactions(false)
  }

  const handleComment = () => {
    setShowComments(!showComments)
  }

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault()
    if (newComment.trim()) {
      console.log("Adding comment:", newComment)
      setCommentsCount((prev) => prev + 1)
      setNewComment("")
    }
  }

  const handleSave = () => {
    setSaved(!saved)
  }

  const getReactionIcon = () => {
    switch (currentReaction) {
      case "love":
        return <Heart className="w-4 h-4 fill-current text-red-500" />
      case "laugh":
        return <span className="text-yellow-500">😂</span>
      case "wow":
        return <span className="text-yellow-500">😮</span>
      case "sad":
        return <span className="text-yellow-500">😢</span>
      case "angry":
        return <span className="text-red-500">😠</span>
      default:
        return <ThumbsUp className={`w-4 h-4 ${liked ? "fill-current text-primary" : ""}`} />
    }
  }

  const getReactionText = () => {
    switch (currentReaction) {
      case "love":
        return "أحب"
      case "laugh":
        return "مضحك"
      case "wow":
        return "رائع"
      case "sad":
        return "حزين"
      case "angry":
        return "غاضب"
      default:
        return "إعجاب"
    }
  }

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <img
              src={post.avatar || "/placeholder.svg?height=40&width=40&query=user-avatar"}
              alt={post.author}
              className="w-10 h-10 rounded-full object-cover"
            />
            <div>
              <h3 className="font-semibold hover:underline cursor-pointer">{post.author}</h3>
              <p className="text-sm text-muted-foreground">{post.timestamp}</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" onClick={handleSave}>
              <Bookmark className={`w-4 h-4 ${saved ? "fill-current text-primary" : ""}`} />
            </Button>
            <Button variant="ghost" size="icon">
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="mb-3 text-right leading-relaxed">
          {post.content.split(/(\s+)/).map((word, index) => {
            if (word.startsWith("#")) {
              return (
                <span key={index} className="text-primary hover:underline cursor-pointer font-medium">
                  {word}
                </span>
              )
            } else if (word.startsWith("@")) {
              return (
                <span key={index} className="text-primary hover:underline cursor-pointer font-medium">
                  {word}
                </span>
              )
            }
            return word
          })}
        </div>

        {post.image && (
          <div className="mb-3 rounded-lg overflow-hidden">
            <img
              src={post.image || "/placeholder.svg"}
              alt="Post image"
              className="w-full h-auto object-cover cursor-pointer hover:opacity-95 transition-opacity"
            />
          </div>
        )}

        <div className="flex items-center justify-between text-sm text-muted-foreground mb-3">
          <div className="flex items-center gap-1">
            <div className="flex items-center">
              <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                <ThumbsUp className="w-3 h-3 text-white" />
              </div>
              <div className="w-5 h-5 bg-red-500 rounded-full flex items-center justify-center -mr-1">
                <Heart className="w-3 h-3 text-white fill-current" />
              </div>
              <div className="w-5 h-5 bg-yellow-500 rounded-full flex items-center justify-center -mr-1">
                <span className="text-xs">😂</span>
              </div>
            </div>
            <span className="mr-2 hover:underline cursor-pointer">{likesCount}</span>
          </div>
          <div className="flex gap-4">
            <span className="hover:underline cursor-pointer" onClick={handleComment}>
              {commentsCount} تعليق
            </span>
            <span className="hover:underline cursor-pointer" onClick={() => setShowShareDialog(true)}>
              {post.shares} مشاركة
            </span>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-border relative">
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              className={`gap-2 flex-1 ${liked ? "text-primary" : ""}`}
              onClick={handleLike}
              onMouseEnter={() => setShowReactions(true)}
              onMouseLeave={() => setTimeout(() => setShowReactions(false), 300)}
            >
              {getReactionIcon()}
              {getReactionText()}
            </Button>

            {showReactions && (
              <div
                className="absolute bottom-full left-0 mb-2 z-10"
                onMouseEnter={() => setShowReactions(true)}
                onMouseLeave={() => setShowReactions(false)}
              >
                <LikeReactions onReaction={handleReaction} currentReaction={currentReaction} />
              </div>
            )}
          </div>

          <Button variant="ghost" size="sm" className="gap-2 flex-1" onClick={handleComment}>
            <MessageCircle className="w-4 h-4" />
            تعليق
          </Button>
          <Button variant="ghost" size="sm" className="gap-2 flex-1" onClick={() => setShowShareDialog(true)}>
            <Share className="w-4 h-4" />
            مشاركة
          </Button>
        </div>

        {showComments && (
          <div className="mt-4 pt-4 border-t border-border space-y-4">
            <CommentsList postId={post.id} />

            <form onSubmit={handleSubmitComment} className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary rounded-full flex-shrink-0"></div>
              <div className="flex-1 relative">
                <Input
                  placeholder="اكتب تعليقاً..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  className="pr-20 text-right"
                />
                <div className="absolute left-2 top-1/2 transform -translate-y-1/2 flex items-center gap-1">
                  <Button type="button" size="icon" variant="ghost" className="w-8 h-8">
                    <Smile className="w-4 h-4" />
                  </Button>
                  <Button type="submit" size="icon" variant="ghost" className="w-8 h-8" disabled={!newComment.trim()}>
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </form>
          </div>
        )}

        {showShareDialog && <ShareDialog post={post} onClose={() => setShowShareDialog(false)} />}
      </CardContent>
    </Card>
  )
}
