import { RegisterForm } from "@/components/register-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function RegisterPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-primary mb-2">فيسبوك العربي</h1>
          <p className="text-muted-foreground">انضم إلى مجتمعنا اليوم</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>إنشاء حساب جديد</CardTitle>
            <CardDescription>املأ البيانات التالية لإنشاء حسابك</CardDescription>
          </CardHeader>
          <CardContent>
            <RegisterForm />
          </CardContent>
        </Card>

        <div className="text-center mt-6">
          <p className="text-sm text-muted-foreground">
            لديك حساب بالفعل؟{" "}
            <a href="/" className="text-primary hover:underline font-medium">
              تسجيل الدخول
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}
