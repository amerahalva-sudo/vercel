"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { MediaGallery } from "@/components/media-gallery"
import { MediaUploader } from "@/components/media-uploader"
import { Search, Upload, Filter, Grid, List } from "lucide-react"

export default function MediaPage() {
  const [showUploader, setShowUploader] = useState(false)
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [searchQuery, setSearchQuery] = useState("")

  const handleMediaUpload = (files: any[]) => {
    console.log("Uploaded files:", files)
    setShowUploader(false)
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="max-w-7xl mx-auto p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold">مكتبة الوسائط</h1>
            <p className="text-muted-foreground">إدارة صورك وفيديوهاتك</p>
          </div>
          <Button onClick={() => setShowUploader(true)} className="bg-primary hover:bg-primary/90">
            <Upload className="w-4 h-4 ml-2" />
            رفع ملفات جديدة
          </Button>
        </div>

        {/* Search and Filters */}
        <div className="flex items-center gap-4 mb-6">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="البحث في الوسائط..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10 text-right"
            />
          </div>
          <Button variant="outline">
            <Filter className="w-4 h-4 ml-2" />
            تصفية
          </Button>
          <div className="flex items-center border rounded-lg">
            <Button variant={viewMode === "grid" ? "default" : "ghost"} size="sm" onClick={() => setViewMode("grid")}>
              <Grid className="w-4 h-4" />
            </Button>
            <Button variant={viewMode === "list" ? "default" : "ghost"} size="sm" onClick={() => setViewMode("list")}>
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">جميع الملفات</TabsTrigger>
            <TabsTrigger value="images">الصور</TabsTrigger>
            <TabsTrigger value="videos">الفيديوهات</TabsTrigger>
            <TabsTrigger value="recent">الأحدث</TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            <MediaGallery viewMode={viewMode} searchQuery={searchQuery} filter="all" />
          </TabsContent>

          <TabsContent value="images">
            <MediaGallery viewMode={viewMode} searchQuery={searchQuery} filter="images" />
          </TabsContent>

          <TabsContent value="videos">
            <MediaGallery viewMode={viewMode} searchQuery={searchQuery} filter="videos" />
          </TabsContent>

          <TabsContent value="recent">
            <MediaGallery viewMode={viewMode} searchQuery={searchQuery} filter="recent" />
          </TabsContent>
        </Tabs>

        {showUploader && <MediaUploader onUpload={handleMediaUpload} onClose={() => setShowUploader(false)} />}
      </div>
    </div>
  )
}
