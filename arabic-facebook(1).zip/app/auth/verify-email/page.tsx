import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function VerifyEmailPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-primary mb-2">فيس اردني</h1>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>تحقق من بريدك الإلكتروني</CardTitle>
            <CardDescription>تم إرسال رابط التفعيل إلى بريدك الإلكتروني</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground text-center">
              يرجى فتح بريدك الإلكتروني والنقر على رابط التفعيل لإكمال إنشاء حسابك.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
