import type React from "react"
import type { Metadata } from "next"
import { Cairo, Amiri } from "next/font/google"
import { RTLProvider } from "@/components/rtl-provider"
import { Footer } from "@/components/footer"
import "./globals.css"

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  display: "swap",
  variable: "--font-cairo",
  weight: ["300", "400", "500", "600", "700", "800", "900"],
})

const amiri = Amiri({
  subsets: ["arabic", "latin"],
  weight: ["400", "700"],
  style: ["normal", "italic"],
  display: "swap",
  variable: "--font-amiri",
})

export const metadata: Metadata = {
  title: "فيس اردني - Fais Urduni",
  description: "منصة التواصل الاجتماعي الأردنية - Jordanian Social Media Platform",
  keywords: "فيس اردني, أردن, تواصل اجتماعي, منصة, أصدقاء, الأردن",
  authors: [{ name: "Fais Urduni Team" }],
  openGraph: {
    title: "فيس اردني - Fais Urduni",
    description: "منصة التواصل الاجتماعي الأردنية",
    locale: "ar_JO",
    type: "website",
  },
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl" className={`${cairo.variable} ${amiri.variable}`}>
      <body className="font-sans antialiased arabic-text min-h-screen flex flex-col">
        <RTLProvider>
          <div className="flex-1">{children}</div>
          <Footer />
        </RTLProvider>
      </body>
    </html>
  )
}
