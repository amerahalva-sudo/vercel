"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LiveStreamSetup } from "@/components/live-stream-setup"
import { LiveStreamViewer } from "@/components/live-stream-viewer"
import { LiveStreamsGrid } from "@/components/live-streams-grid"
import { Video, Users, Clock, TrendingUp } from "lucide-react"

export default function LivePage() {
  const [activeTab, setActiveTab] = useState("discover")
  const [isStreaming, setIsStreaming] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="max-w-7xl mx-auto p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold">البث المباشر</h1>
            <p className="text-muted-foreground">شارك لحظاتك مع الأصدقاء في الوقت الفعلي</p>
          </div>
          <Button onClick={() => setActiveTab("create")} className="bg-red-600 hover:bg-red-700 text-white">
            <Video className="w-4 h-4 ml-2" />
            بدء بث مباشر
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">البث المباشر الآن</CardTitle>
              <Video className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">127</div>
              <p className="text-xs text-muted-foreground">بث نشط</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">المشاهدين</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12,543</div>
              <p className="text-xs text-muted-foreground">مشاهد نشط</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">متوسط المدة</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">45 دقيقة</div>
              <p className="text-xs text-muted-foreground">للبث الواحد</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">الأكثر شعبية</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">الطبخ</div>
              <p className="text-xs text-muted-foreground">فئة البث</p>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="discover">اكتشاف البث</TabsTrigger>
            <TabsTrigger value="following">المتابعين</TabsTrigger>
            <TabsTrigger value="create">إنشاء بث</TabsTrigger>
            <TabsTrigger value="history">سجل البث</TabsTrigger>
          </TabsList>

          <TabsContent value="discover">
            <LiveStreamsGrid filter="all" />
          </TabsContent>

          <TabsContent value="following">
            <LiveStreamsGrid filter="following" />
          </TabsContent>

          <TabsContent value="create">
            <LiveStreamSetup onStartStream={() => setIsStreaming(true)} />
          </TabsContent>

          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle>سجل البث المباشر</CardTitle>
                <CardDescription>جميع البثوث السابقة والإحصائيات</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <p className="text-muted-foreground">لا توجد بثوث سابقة</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {isStreaming && (
          <LiveStreamViewer streamId="current-stream" isOwner={true} onEndStream={() => setIsStreaming(false)} />
        )}
      </div>
    </div>
  )
}
