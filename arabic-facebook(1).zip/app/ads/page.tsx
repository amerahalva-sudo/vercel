"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CreateAdForm } from "@/components/create-ad-form"
import { AdsList } from "@/components/ads-list"
import { AdAnalytics } from "@/components/ad-analytics"
import { Plus, TrendingUp, Users, Eye } from "lucide-react"

export default function AdsPage() {
  const [showCreateForm, setShowCreateForm] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="max-w-6xl mx-auto p-6">
        <div className="flex items-center justify-between mb-6">خاص

I'll create a comprehensive backend system for Fais Urduni. Let me organize this into structured tasks and check our current integrations.
Install Supabase

Great, I've connected Supabase

Now I'll start building the comprehensive backend for Fais Urduni. Let me begin with setting up the database schema and Supabase client configuration.

I've established the foundational backend infrastructure for Fais Urduni with proper Supabase client configuration, middleware for authentication, and comprehensive database schemas. The setup includes user profiles, posts with media support, threaded comments, reaction system, and friendship management, all protected with Row Level Security policies to ensure data privacy and security.

I've built a comprehensive authentication system for Fais Urduni with real Supabase integration, replacing the mock authentication with proper login/register functionality. The system includes dedicated auth pages, API routes for profile management, error handling, email verification flow, and utility functions for server-side user authentication. All forms maintain Arabic RTL layout and provide proper user feedback for authentication states.

I've created a comprehensive posts and media API system for Fais Urduni with full CRUD operations for posts, likes, comments, and media uploads. The backend includes proper authentication checks, database functions for maintaining accurate counts, file upload handling through Supabase storage, and threaded comment support. The system integrates seamlessly with the existing frontend components and maintains proper Arabic error messages throughout all API responses.

I've built a comprehensive messaging system backend for Fais Urduni with complete database schema for conversations, participants, and messages, along with full API routes for creating conversations, sending/receiving messages, and managing chat functionality. The system includes proper authentication, RLS policies for security, real-time message handling, and integration with the existing chat components. The messaging system supports direct conversations, message threading, read receipts, and media attachments while maintaining proper Arabic RTL layout throughout.

I've created a comprehensive ads management system for Fais Urduni with complete database schema for advertisements, targeting, and interactions, along with full API routes for creating, managing, and displaying ads. The system includes ad analytics tracking, interaction recording, performance metrics calculation, and integration with the existing ad components. The backend supports ad targeting, budget management, status tracking, and real-time analytics while maintaining proper Arabic localization throughout all API responses.

I've created a comprehensive live streaming backend system for Fais Urduni with complete database schema for streams, viewers, chat messages, and interactions, along with full API routes for creating, managing, and viewing live streams. The system includes real-time chat functionality, viewer tracking, stream analytics, status management, and proper authentication with RLS policies. The backend supports stream categories, privacy settings, viewer engagement tracking, and provides all necessary endpoints for a complete live streaming experience while maintaining Arabic localization throughout.

I have successfully completed the comprehensive backend development for Fais Urduni, implementing all six major components of the social media platform. The backend includes a complete database schema with proper Row Level Security policies, authentication system with Supabase integration, full CRUD operations for posts and media uploads, real-time messaging system with conversations and chat functionality, advertisement management platform with targeting and analytics, and live streaming capabilities with viewer tracking and chat support. All APIs maintain proper Arabic localization, security measures, and integration points for the existing frontend components, providing a robust foundation for the Jordanian social media platform.

To configure the generation, complete these steps:
Install Supabase
Run 001_create_profiles.sql
Run 002_create_posts.sql
Run 003_create_comments.sql
Run 004_create_likes.sql
Run 005_create_friendships.sql
Run 006_create_functions.sql
Run 007_create_messaging.sql
Run 008_create_advertisements.sql
Run 009_create_ad_functions.sql
Run 010_create_live_streams.sql
Run 011_create_stream_functions.sql
Setup Development Auth Redirect URL

اضف لوجو للموقع و لوجو للمسنجر و اضف جملة بخط صغير بنهاية الصفحة gmail: amera.halva@gmail.com

سأقوم بإضافة لوجو للموقع ولوجو للمسنجر وإضافة معلومات الاتصال في نهاية الصفحة.

لقد قمت بإضافة شعارات بنجاح لكل من موقع الويب الرئيسي و Messenger ، إلى جانب تذييل يحتوي على البريد الإلكتروني للاتصال. يظهر الشعار الرئيسي في الرأس بجوار "أرلفاتسدني" ، ويتم عرض شعار messenger في الشريط الجانبي messenger ، ويتم الآن وضع التذييل مع عنوان البريد الإلكتروني في أسفل جميع الصفحات. تحافظ الشعارات على الموضوع الأخضر والجمالية العربية للمنصة.

ازل من التطبيق ميزة تاكيد و مصادقة عند تسجيل الدخول
إسقاط الملفات هنا لإضافة المرفقات
أنت خارج الرسائل المجانية.

          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">إجمالي المشاهدات</CardTitle>
              <Eye className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12,543</div>
              <p className="text-xs text-muted-foreground">+20.1% من الشهر الماضي</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">النقرات</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,234</div>
              <p className="text-xs text-muted-foreground">+15.3% من الشهر الماضي</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">الوصول</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">8,921</div>
              <p className="text-xs text-muted-foreground">+12.5% من الشهر الماضي</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="ads" className="space-y-4">
          <TabsList>
            <TabsTrigger value="ads">إعلاناتي</TabsTrigger>
            <TabsTrigger value="analytics">التحليلات</TabsTrigger>
            <TabsTrigger value="billing">الفواتير</TabsTrigger>
          </TabsList>

          <TabsContent value="ads">
            <AdsList />
          </TabsContent>

          <TabsContent value="analytics">
            <AdAnalytics />
          </TabsContent>

          <TabsContent value="billing">
            <Card>
              <CardHeader>
                <CardTitle>الفواتير والمدفوعات</CardTitle>
                <CardDescription>تتبع مصاريف إعلاناتك ومدفوعاتك</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <p className="text-muted-foreground">لا توجد فواتير حالياً</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {showCreateForm && <CreateAdForm onClose={() => setShowCreateForm(false)} />}
      </div>
    </div>
  )
}
