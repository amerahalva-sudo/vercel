import { NewsFeed } from "@/components/news-feed"
import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"

export default function FeedPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 max-w-2xl mx-auto p-4">
          <NewsFeed />
        </main>
        <div className="w-80 p-4 hidden lg:block">
          <div className="sticky top-20">
            <h3 className="font-semibold mb-4">جهات الاتصال</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-3 p-2 hover:bg-muted rounded-lg cursor-pointer">
                <div className="w-8 h-8 bg-primary rounded-full"></div>
                <span className="text-sm">أحمد محمد</span>
              </div>
              <div className="flex items-center gap-3 p-2 hover:bg-muted rounded-lg cursor-pointer">
                <div className="w-8 h-8 bg-secondary rounded-full"></div>
                <span className="text-sm">فاطمة علي</span>
              </div>
              <div className="flex items-center gap-3 p-2 hover:bg-muted rounded-lg cursor-pointer">
                <div className="w-8 h-8 bg-accent rounded-full"></div>
                <span className="text-sm">محمد حسن</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
