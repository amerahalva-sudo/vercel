"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { MessengerSidebar } from "@/components/messenger-sidebar"
import { ChatWindow } from "@/components/chat-window"

export default function MessengerPage() {
  const [selectedChat, setSelectedChat] = useState<string | null>("ahmed-123")

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="flex h-[calc(100vh-4rem)]">
        <MessengerSidebar selectedChat={selectedChat} onSelectChat={setSelectedChat} />
        <div className="flex-1">
          {selectedChat ? (
            <ChatWindow chatId={selectedChat} />
          ) : (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <div className="text-center">
                <h3 className="text-xl font-semibold mb-2">اختر محادثة</h3>
                <p>اختر من قائمة الأصدقاء لبدء المحادثة</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
