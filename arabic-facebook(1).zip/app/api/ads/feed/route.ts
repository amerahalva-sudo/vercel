import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const limit = Number.parseInt(searchParams.get("limit") || "5")

    // Get active ads that haven't been shown to this user recently
    const { data: ads, error } = await supabase
      .from("advertisements")
      .select(`
        *,
        profiles:user_id (
          display_name,
          avatar_url
        )
      `)
      .eq("status", "active")
      .lte("start_date", new Date().toISOString())
      .gte("end_date", new Date().toISOString())
      .neq("user_id", user.id)
      .limit(limit)

    if (error) {
      return NextResponse.json({ error: "خطأ في جلب الإعلانات" }, { status: 500 })
    }

    // Record impressions for these ads
    for (const ad of ads || []) {
      await supabase.from("ad_interactions").insert({
        ad_id: ad.id,
        user_id: user.id,
        interaction_type: "impression",
      })
    }

    return NextResponse.json({ ads })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
