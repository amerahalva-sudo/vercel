import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    const body = await request.json()
    const { interaction_type, metadata = {} } = body

    if (!["impression", "click", "like", "comment", "share", "conversion"].includes(interaction_type)) {
      return NextResponse.json({ error: "نوع التفاعل غير صحيح" }, { status: 400 })
    }

    // Record the interaction
    const { error } = await supabase.from("ad_interactions").insert({
      ad_id: params.id,
      user_id: user?.id || null,
      interaction_type,
      metadata,
    })

    if (error) {
      return NextResponse.json({ error: "خطأ في تسجيل التفاعل" }, { status: 500 })
    }

    // Update ad statistics
    const updateField = `${interaction_type}s`
    if (["impressions", "clicks", "conversions"].includes(updateField)) {
      await supabase.rpc("increment_ad_stat", {
        ad_id: params.id,
        stat_field: updateField,
      })
    }

    return NextResponse.json({ message: "تم تسجيل التفاعل بنجاح" })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
