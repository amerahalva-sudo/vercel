import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const { data: ad, error } = await supabase
      .from("advertisements")
      .select(`
        *,
        profiles:user_id (
          display_name,
          avatar_url
        )
      `)
      .eq("id", params.id)
      .single()

    if (error) {
      return NextResponse.json({ error: "الإعلان غير موجود" }, { status: 404 })
    }

    // Get ad analytics
    const { data: analytics } = await supabase.from("ad_interactions").select("interaction_type").eq("ad_id", params.id)

    const analyticsData = {
      impressions: analytics?.filter((a) => a.interaction_type === "impression").length || 0,
      clicks: analytics?.filter((a) => a.interaction_type === "click").length || 0,
      likes: analytics?.filter((a) => a.interaction_type === "like").length || 0,
      comments: analytics?.filter((a) => a.interaction_type === "comment").length || 0,
      shares: analytics?.filter((a) => a.interaction_type === "share").length || 0,
    }

    return NextResponse.json({ ad: { ...ad, analytics: analyticsData } })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const body = await request.json()
    const { title, description, cta_text, cta_link, budget_daily, status } = body

    const { data: ad, error } = await supabase
      .from("advertisements")
      .update({
        title,
        description,
        cta_text,
        cta_link,
        budget_daily,
        status,
        updated_at: new Date().toISOString(),
      })
      .eq("id", params.id)
      .eq("user_id", user.id)
      .select(`
        *,
        profiles:user_id (
          display_name,
          avatar_url
        )
      `)
      .single()

    if (error) {
      return NextResponse.json({ error: "خطأ في تحديث الإعلان" }, { status: 500 })
    }

    return NextResponse.json({ ad })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const { error } = await supabase.from("advertisements").delete().eq("id", params.id).eq("user_id", user.id)

    if (error) {
      return NextResponse.json({ error: "خطأ في حذف الإعلان" }, { status: 500 })
    }

    return NextResponse.json({ message: "تم حذف الإعلان بنجاح" })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
