import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const offset = (page - 1) * limit

    let query = supabase
      .from("advertisements")
      .select(`
        *,
        profiles:user_id (
          display_name,
          avatar_url
        )
      `)
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })

    if (status) {
      query = query.eq("status", status)
    }

    const { data: ads, error } = await query.range(offset, offset + limit - 1)

    if (error) {
      return NextResponse.json({ error: "خطأ في جلب الإعلانات" }, { status: 500 })
    }

    return NextResponse.json({ ads })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const body = await request.json()
    const {
      title,
      description,
      ad_type,
      media_urls,
      cta_text,
      cta_link,
      target_audience,
      budget_daily,
      duration_days,
    } = body

    if (!title || !description || !budget_daily || !duration_days) {
      return NextResponse.json({ error: "البيانات المطلوبة مفقودة" }, { status: 400 })
    }

    const startDate = new Date()
    const endDate = new Date()
    endDate.setDate(startDate.getDate() + duration_days)

    const { data: ad, error } = await supabase
      .from("advertisements")
      .insert({
        user_id: user.id,
        title,
        description,
        ad_type,
        media_urls,
        cta_text,
        cta_link,
        target_audience,
        budget_daily,
        budget_total: budget_daily * duration_days,
        duration_days,
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
        status: "pending",
      })
      .select(`
        *,
        profiles:user_id (
          display_name,
          avatar_url
        )
      `)
      .single()

    if (error) {
      return NextResponse.json({ error: "خطأ في إنشاء الإعلان" }, { status: 500 })
    }

    return NextResponse.json({ ad })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
