import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const formData = await request.formData()
    const files = formData.getAll("files") as File[]

    if (!files || files.length === 0) {
      return NextResponse.json({ error: "لم يتم تحديد ملفات" }, { status: 400 })
    }

    const uploadedFiles = []

    for (const file of files) {
      const fileExt = file.name.split(".").pop()
      const fileName = `${user.id}/${Date.now()}.${fileExt}`

      const { data, error } = await supabase.storage.from("media").upload(fileName, file, {
        cacheControl: "3600",
        upsert: false,
      })

      if (error) {
        console.error("Upload error:", error)
        continue
      }

      const {
        data: { publicUrl },
      } = supabase.storage.from("media").getPublicUrl(data.path)

      uploadedFiles.push({
        id: data.path,
        url: publicUrl,
        type: file.type.startsWith("image/") ? "image" : "video",
        name: file.name,
      })
    }

    return NextResponse.json({ files: uploadedFiles })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
