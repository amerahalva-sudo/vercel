import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const body = await request.json()
    const { reaction_type = "like" } = body

    // Check if user already liked this post
    const { data: existingLike } = await supabase
      .from("likes")
      .select("*")
      .eq("user_id", user.id)
      .eq("post_id", params.id)
      .single()

    if (existingLike) {
      // Update existing reaction
      const { error } = await supabase.from("likes").update({ reaction_type }).eq("id", existingLike.id)

      if (error) {
        return NextResponse.json({ error: "خطأ في تحديث الإعجاب" }, { status: 500 })
      }
    } else {
      // Create new like
      const { error } = await supabase.from("likes").insert({
        user_id: user.id,
        post_id: params.id,
        reaction_type,
      })

      if (error) {
        return NextResponse.json({ error: "خطأ في إضافة الإعجاب" }, { status: 500 })
      }

      // Update likes count
      const { error: updateError } = await supabase.rpc("increment_likes_count", {
        post_id: params.id,
      })

      if (updateError) {
        console.error("Error updating likes count:", updateError)
      }
    }

    return NextResponse.json({ message: "تم تحديث الإعجاب بنجاح" })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const { error } = await supabase.from("likes").delete().eq("user_id", user.id).eq("post_id", params.id)

    if (error) {
      return NextResponse.json({ error: "خطأ في إلغاء الإعجاب" }, { status: 500 })
    }

    // Update likes count
    const { error: updateError } = await supabase.rpc("decrement_likes_count", {
      post_id: params.id,
    })

    if (updateError) {
      console.error("Error updating likes count:", updateError)
    }

    return NextResponse.json({ message: "تم إلغاء الإعجاب بنجاح" })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
