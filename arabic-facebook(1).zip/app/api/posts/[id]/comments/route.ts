import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const { data: comments, error } = await supabase
      .from("comments")
      .select(`
        *,
        profiles:user_id (
          display_name,
          avatar_url
        )
      `)
      .eq("post_id", params.id)
      .is("parent_id", null)
      .order("created_at", { ascending: true })

    if (error) {
      return NextResponse.json({ error: "خطأ في جلب التعليقات" }, { status: 500 })
    }

    // Get replies for each comment
    const commentsWithReplies = await Promise.all(
      comments.map(async (comment) => {
        const { data: replies } = await supabase
          .from("comments")
          .select(`
            *,
            profiles:user_id (
              display_name,
              avatar_url
            )
          `)
          .eq("parent_id", comment.id)
          .order("created_at", { ascending: true })

        return { ...comment, replies: replies || [] }
      }),
    )

    return NextResponse.json({ comments: commentsWithReplies })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const body = await request.json()
    const { content, parent_id } = body

    if (!content.trim()) {
      return NextResponse.json({ error: "محتوى التعليق مطلوب" }, { status: 400 })
    }

    const { data: comment, error } = await supabase
      .from("comments")
      .insert({
        post_id: params.id,
        user_id: user.id,
        content,
        parent_id,
      })
      .select(`
        *,
        profiles:user_id (
          display_name,
          avatar_url
        )
      `)
      .single()

    if (error) {
      return NextResponse.json({ error: "خطأ في إضافة التعليق" }, { status: 500 })
    }

    // Update comments count
    const { error: updateError } = await supabase.rpc("increment_comments_count", {
      post_id: params.id,
    })

    if (updateError) {
      console.error("Error updating comments count:", updateError)
    }

    return NextResponse.json({ comment })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
