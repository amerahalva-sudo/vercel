import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    // Get conversations where user is a participant
    const { data: conversations, error } = await supabase
      .from("conversation_participants")
      .select(`
        conversation_id,
        conversations!inner (
          id,
          type,
          name,
          avatar_url,
          updated_at
        )
      `)
      .eq("user_id", user.id)
      .order("conversations.updated_at", { ascending: false })

    if (error) {
      return NextResponse.json({ error: "خطأ في جلب المحادثات" }, { status: 500 })
    }

    // Get last message and unread count for each conversation
    const conversationsWithDetails = await Promise.all(
      conversations.map(async (conv) => {
        const conversationId = conv.conversations.id

        // Get last message
        const { data: lastMessage } = await supabase
          .from("messages")
          .select(`
            content,
            created_at,
            profiles:sender_id (
              display_name
            )
          `)
          .eq("conversation_id", conversationId)
          .order("created_at", { ascending: false })
          .limit(1)
          .single()

        // Get unread count
        const { data: participant } = await supabase
          .from("conversation_participants")
          .select("last_read_at")
          .eq("conversation_id", conversationId)
          .eq("user_id", user.id)
          .single()

        const { count: unreadCount } = await supabase
          .from("messages")
          .select("*", { count: "exact", head: true })
          .eq("conversation_id", conversationId)
          .gt("created_at", participant?.last_read_at || "1970-01-01")
          .neq("sender_id", user.id)

        // Get other participants for direct conversations
        let otherParticipant = null
        if (conv.conversations.type === "direct") {
          const { data: participants } = await supabase
            .from("conversation_participants")
            .select(`
              profiles:user_id (
                display_name,
                avatar_url
              )
            `)
            .eq("conversation_id", conversationId)
            .neq("user_id", user.id)
            .limit(1)
            .single()

          otherParticipant = participants?.profiles
        }

        return {
          ...conv.conversations,
          lastMessage: lastMessage?.content || "",
          lastMessageTime: lastMessage?.created_at,
          unreadCount: unreadCount || 0,
          otherParticipant,
        }
      }),
    )

    return NextResponse.json({ conversations: conversationsWithDetails })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const body = await request.json()
    const { participant_id, type = "direct", name } = body

    if (!participant_id) {
      return NextResponse.json({ error: "معرف المشارك مطلوب" }, { status: 400 })
    }

    // Check if direct conversation already exists
    if (type === "direct") {
      const { data: existingConv } = await supabase
        .from("conversation_participants")
        .select(`
          conversation_id,
          conversations!inner (
            id,
            type
          )
        `)
        .eq("user_id", user.id)
        .eq("conversations.type", "direct")

      if (existingConv) {
        for (const conv of existingConv) {
          const { data: otherParticipant } = await supabase
            .from("conversation_participants")
            .select("user_id")
            .eq("conversation_id", conv.conversation_id)
            .eq("user_id", participant_id)
            .single()

          if (otherParticipant) {
            return NextResponse.json({ conversation: { id: conv.conversation_id } })
          }
        }
      }
    }

    // Create new conversation
    const { data: conversation, error: convError } = await supabase
      .from("conversations")
      .insert({
        type,
        name,
      })
      .select()
      .single()

    if (convError) {
      return NextResponse.json({ error: "خطأ في إنشاء المحادثة" }, { status: 500 })
    }

    // Add participants
    const participants = [
      { conversation_id: conversation.id, user_id: user.id },
      { conversation_id: conversation.id, user_id: participant_id },
    ]

    const { error: participantsError } = await supabase.from("conversation_participants").insert(participants)

    if (participantsError) {
      return NextResponse.json({ error: "خطأ في إضافة المشاركين" }, { status: 500 })
    }

    return NextResponse.json({ conversation })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
