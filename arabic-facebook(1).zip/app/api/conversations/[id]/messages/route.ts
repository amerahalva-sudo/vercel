import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "50")
    const offset = (page - 1) * limit

    // Verify user is participant in this conversation
    const { data: participant } = await supabase
      .from("conversation_participants")
      .select("*")
      .eq("conversation_id", params.id)
      .eq("user_id", user.id)
      .single()

    if (!participant) {
      return NextResponse.json({ error: "غير مصرح للوصول لهذه المحادثة" }, { status: 403 })
    }

    const { data: messages, error } = await supabase
      .from("messages")
      .select(`
        *,
        profiles:sender_id (
          display_name,
          avatar_url
        ),
        reply_to:reply_to_id (
          content,
          profiles:sender_id (
            display_name
          )
        )
      `)
      .eq("conversation_id", params.id)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1)

    if (error) {
      return NextResponse.json({ error: "خطأ في جلب الرسائل" }, { status: 500 })
    }

    // Update last read timestamp
    await supabase
      .from("conversation_participants")
      .update({ last_read_at: new Date().toISOString() })
      .eq("conversation_id", params.id)
      .eq("user_id", user.id)

    return NextResponse.json({ messages: messages.reverse() })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const body = await request.json()
    const { content, message_type = "text", media_url, reply_to_id } = body

    if (!content.trim() && !media_url) {
      return NextResponse.json({ error: "محتوى الرسالة مطلوب" }, { status: 400 })
    }

    // Verify user is participant in this conversation
    const { data: participant } = await supabase
      .from("conversation_participants")
      .select("*")
      .eq("conversation_id", params.id)
      .eq("user_id", user.id)
      .single()

    if (!participant) {
      return NextResponse.json({ error: "غير مصرح للوصول لهذه المحادثة" }, { status: 403 })
    }

    const { data: message, error } = await supabase
      .from("messages")
      .insert({
        conversation_id: params.id,
        sender_id: user.id,
        content,
        message_type,
        media_url,
        reply_to_id,
      })
      .select(`
        *,
        profiles:sender_id (
          display_name,
          avatar_url
        )
      `)
      .single()

    if (error) {
      return NextResponse.json({ error: "خطأ في إرسال الرسالة" }, { status: 500 })
    }

    // Update conversation timestamp
    await supabase.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", params.id)

    return NextResponse.json({ message })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
