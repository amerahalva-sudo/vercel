import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    // Verify user is participant and get conversation details
    const { data: conversation, error } = await supabase
      .from("conversation_participants")
      .select(`
        conversations!inner (
          id,
          type,
          name,
          avatar_url,
          created_at,
          updated_at
        )
      `)
      .eq("conversation_id", params.id)
      .eq("user_id", user.id)
      .single()

    if (error || !conversation) {
      return NextResponse.json({ error: "المحادثة غير موجودة" }, { status: 404 })
    }

    // Get all participants
    const { data: participants } = await supabase
      .from("conversation_participants")
      .select(`
        user_id,
        joined_at,
        last_read_at,
        profiles:user_id (
          display_name,
          avatar_url
        )
      `)
      .eq("conversation_id", params.id)

    return NextResponse.json({
      conversation: {
        ...conversation.conversations,
        participants,
      },
    })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
