import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const { data: stream, error } = await supabase
      .from("live_streams")
      .select(`
        *,
        profiles:user_id (
          display_name,
          avatar_url
        )
      `)
      .eq("id", params.id)
      .single()

    if (error) {
      return NextResponse.json({ error: "البث المباشر غير موجود" }, { status: 404 })
    }

    // Get current viewer count
    const { count: viewerCount } = await supabase
      .from("stream_viewers")
      .select("*", { count: "exact", head: true })
      .eq("stream_id", params.id)
      .is("left_at", null)

    return NextResponse.json({
      stream: {
        ...stream,
        current_viewers: viewerCount || 0,
      },
    })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const body = await request.json()
    const { status, title, description, viewer_count } = body

    const updateData: any = {
      updated_at: new Date().toISOString(),
    }

    if (status) updateData.status = status
    if (title) updateData.title = title
    if (description) updateData.description = description
    if (viewer_count !== undefined) updateData.viewer_count = viewer_count

    // Handle status transitions
    if (status === "live" && !updateData.started_at) {
      updateData.started_at = new Date().toISOString()
    } else if (status === "ended") {
      updateData.ended_at = new Date().toISOString()

      // Calculate duration if stream was live
      const { data: currentStream } = await supabase
        .from("live_streams")
        .select("started_at")
        .eq("id", params.id)
        .single()

      if (currentStream?.started_at) {
        const duration = Math.floor((new Date().getTime() - new Date(currentStream.started_at).getTime()) / 1000)
        updateData.duration_seconds = duration
      }
    }

    const { data: stream, error } = await supabase
      .from("live_streams")
      .update(updateData)
      .eq("id", params.id)
      .eq("user_id", user.id)
      .select(`
        *,
        profiles:user_id (
          display_name,
          avatar_url
        )
      `)
      .single()

    if (error) {
      return NextResponse.json({ error: "خطأ في تحديث البث المباشر" }, { status: 500 })
    }

    return NextResponse.json({ stream })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const { error } = await supabase.from("live_streams").delete().eq("id", params.id).eq("user_id", user.id)

    if (error) {
      return NextResponse.json({ error: "خطأ في حذف البث المباشر" }, { status: 500 })
    }

    return NextResponse.json({ message: "تم حذف البث المباشر بنجاح" })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
