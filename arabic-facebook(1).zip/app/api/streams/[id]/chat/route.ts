import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const limit = Number.parseInt(searchParams.get("limit") || "50")

    const { data: messages, error } = await supabase
      .from("stream_chat_messages")
      .select(`
        *,
        profiles:user_id (
          display_name,
          avatar_url
        )
      `)
      .eq("stream_id", params.id)
      .order("created_at", { ascending: false })
      .limit(limit)

    if (error) {
      return NextResponse.json({ error: "خطأ في جلب رسائل الدردشة" }, { status: 500 })
    }

    return NextResponse.json({ messages: messages.reverse() })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const body = await request.json()
    const { message, message_type = "text" } = body

    if (!message.trim()) {
      return NextResponse.json({ error: "محتوى الرسالة مطلوب" }, { status: 400 })
    }

    const { data: chatMessage, error } = await supabase
      .from("stream_chat_messages")
      .insert({
        stream_id: params.id,
        user_id: user.id,
        message,
        message_type,
      })
      .select(`
        *,
        profiles:user_id (
          display_name,
          avatar_url
        )
      `)
      .single()

    if (error) {
      return NextResponse.json({ error: "خطأ في إرسال الرسالة" }, { status: 500 })
    }

    return NextResponse.json({ message: chatMessage })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
