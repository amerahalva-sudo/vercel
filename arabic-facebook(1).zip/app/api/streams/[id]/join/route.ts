import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    // Check if user is already viewing
    const { data: existingViewer } = await supabase
      .from("stream_viewers")
      .select("*")
      .eq("stream_id", params.id)
      .eq("user_id", user.id)
      .is("left_at", null)
      .single()

    if (existingViewer) {
      return NextResponse.json({ message: "المستخدم يشاهد البث بالفعل" })
    }

    // Add user as viewer
    const { error } = await supabase.from("stream_viewers").insert({
      stream_id: params.id,
      user_id: user.id,
    })

    if (error) {
      return NextResponse.json({ error: "خطأ في الانضمام للبث" }, { status: 500 })
    }

    // Update viewer count
    await supabase.rpc("increment_stream_viewers", {
      stream_id: params.id,
    })

    return NextResponse.json({ message: "تم الانضمام للبث بنجاح" })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
