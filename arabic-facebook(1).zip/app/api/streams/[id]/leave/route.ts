import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    // Update viewer record with leave time
    const { data: viewer } = await supabase
      .from("stream_viewers")
      .select("joined_at")
      .eq("stream_id", params.id)
      .eq("user_id", user.id)
      .is("left_at", null)
      .single()

    if (viewer) {
      const watchDuration = Math.floor((new Date().getTime() - new Date(viewer.joined_at).getTime()) / 1000)

      await supabase
        .from("stream_viewers")
        .update({
          left_at: new Date().toISOString(),
          watch_duration_seconds: watchDuration,
        })
        .eq("stream_id", params.id)
        .eq("user_id", user.id)
        .is("left_at", null)

      // Update viewer count
      await supabase.rpc("decrement_stream_viewers", {
        stream_id: params.id,
      })
    }

    return NextResponse.json({ message: "تم مغادرة البث بنجاح" })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
