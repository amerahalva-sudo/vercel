import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"
import { randomBytes } from "crypto"

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status") || "live"
    const category = searchParams.get("category")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const offset = (page - 1) * limit

    let query = supabase
      .from("live_streams")
      .select(`
        *,
        profiles:user_id (
          display_name,
          avatar_url
        )
      `)
      .eq("status", status)
      .order("created_at", { ascending: false })

    if (category) {
      query = query.eq("category", category)
    }

    const { data: streams, error } = await query.range(offset, offset + limit - 1)

    if (error) {
      return NextResponse.json({ error: "خطأ في جلب البثوث المباشرة" }, { status: 500 })
    }

    return NextResponse.json({ streams })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const body = await request.json()
    const { title, description, category, privacy, allow_comments, allow_sharing } = body

    if (!title) {
      return NextResponse.json({ error: "عنوان البث مطلوب" }, { status: 400 })
    }

    // Generate unique stream key
    const streamKey = randomBytes(32).toString("hex")
    const rtmpUrl = `rtmp://live.faisurduni.com/live/${streamKey}`
    const hlsUrl = `https://live.faisurduni.com/hls/${streamKey}/index.m3u8`

    const { data: stream, error } = await supabase
      .from("live_streams")
      .insert({
        user_id: user.id,
        title,
        description,
        category,
        privacy,
        allow_comments,
        allow_sharing,
        stream_key: streamKey,
        rtmp_url: rtmpUrl,
        hls_url: hlsUrl,
        status: "scheduled",
      })
      .select(`
        *,
        profiles:user_id (
          display_name,
          avatar_url
        )
      `)
      .single()

    if (error) {
      return NextResponse.json({ error: "خطأ في إنشاء البث المباشر" }, { status: 500 })
    }

    return NextResponse.json({ stream })
  } catch (error) {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
