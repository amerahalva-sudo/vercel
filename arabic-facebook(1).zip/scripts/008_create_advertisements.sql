-- Create advertisements table
CREATE TABLE IF NOT EXISTS public.advertisements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  ad_type TEXT DEFAULT 'image' CHECK (ad_type IN ('image', 'video', 'carousel', 'text')),
  media_urls TEXT[],
  cta_text TEXT DEFAULT 'تعرف أكثر',
  cta_link TEXT,
  target_audience JSONB DEFAULT '{}',
  budget_daily DECIMAL(10,2) NOT NULL,
  budget_total DECIMAL(10,2),
  duration_days INTEGER NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'active', 'paused', 'completed', 'rejected')),
  start_date TIMESTAMP WITH TIME ZONE,
  end_date TIMESTAMP WITH TIME ZONE,
  impressions INTEGER DEFAULT 0,
  clicks INTEGER DEFAULT 0,
  conversions INTEGER DEFAULT 0,
  spent_amount DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create ad interactions table
CREATE TABLE IF NOT EXISTS public.ad_interactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ad_id UUID NOT NULL REFERENCES public.advertisements(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  interaction_type TEXT NOT NULL CHECK (interaction_type IN ('impression', 'click', 'like', 'comment', 'share', 'conversion')),
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create ad targeting table
CREATE TABLE IF NOT EXISTS public.ad_targeting (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ad_id UUID NOT NULL REFERENCES public.advertisements(id) ON DELETE CASCADE,
  target_type TEXT NOT NULL CHECK (target_type IN ('age_range', 'location', 'interests', 'gender', 'device')),
  target_value TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.advertisements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ad_interactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ad_targeting ENABLE ROW LEVEL SECURITY;

-- RLS Policies for advertisements
CREATE POLICY "ads_select_own_or_active" ON public.advertisements FOR SELECT USING (
  user_id = auth.uid() OR status = 'active'
);
CREATE POLICY "ads_insert_own" ON public.advertisements FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "ads_update_own" ON public.advertisements FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "ads_delete_own" ON public.advertisements FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for ad_interactions
CREATE POLICY "interactions_select_all" ON public.ad_interactions FOR SELECT USING (true);
CREATE POLICY "interactions_insert_all" ON public.ad_interactions FOR INSERT WITH CHECK (true);

-- RLS Policies for ad_targeting
CREATE POLICY "targeting_select_own" ON public.ad_targeting FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.advertisements WHERE id = ad_targeting.ad_id AND user_id = auth.uid())
);
CREATE POLICY "targeting_insert_own" ON public.ad_targeting FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM public.advertisements WHERE id = ad_targeting.ad_id AND user_id = auth.uid())
);
CREATE POLICY "targeting_update_own" ON public.ad_targeting FOR UPDATE USING (
  EXISTS (SELECT 1 FROM public.advertisements WHERE id = ad_targeting.ad_id AND user_id = auth.uid())
);
CREATE POLICY "targeting_delete_own" ON public.ad_targeting FOR DELETE USING (
  EXISTS (SELECT 1 FROM public.advertisements WHERE id = ad_targeting.ad_id AND user_id = auth.uid())
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS ads_user_id_idx ON public.advertisements(user_id);
CREATE INDEX IF NOT EXISTS ads_status_idx ON public.advertisements(status);
CREATE INDEX IF NOT EXISTS ads_start_date_idx ON public.advertisements(start_date);
CREATE INDEX IF NOT EXISTS ads_end_date_idx ON public.advertisements(end_date);
CREATE INDEX IF NOT EXISTS ad_interactions_ad_id_idx ON public.ad_interactions(ad_id);
CREATE INDEX IF NOT EXISTS ad_interactions_type_idx ON public.ad_interactions(interaction_type);
CREATE INDEX IF NOT EXISTS ad_targeting_ad_id_idx ON public.ad_targeting(ad_id);
