-- Create live streams table
CREATE TABLE IF NOT EXISTS public.live_streams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT DEFAULT 'other' CHECK (category IN ('gaming', 'cooking', 'education', 'music', 'sports', 'travel', 'lifestyle', 'other')),
  privacy TEXT DEFAULT 'public' CHECK (privacy IN ('public', 'friends', 'private')),
  status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'live', 'ended', 'cancelled')),
  stream_key TEXT UNIQUE,
  rtmp_url TEXT,
  hls_url TEXT,
  thumbnail_url TEXT,
  viewer_count INTEGER DEFAULT 0,
  max_viewers INTEGER DEFAULT 0,
  likes_count INTEGER DEFAULT 0,
  comments_count INTEGER DEFAULT 0,
  allow_comments BOOLEAN DEFAULT true,
  allow_sharing BOOLEAN DEFAULT true,
  started_at TIMESTAMP WITH TIME ZONE,
  ended_at TIMESTAMP WITH TIME ZONE,
  duration_seconds INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create stream viewers table
CREATE TABLE IF NOT EXISTS public.stream_viewers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stream_id UUID NOT NULL REFERENCES public.live_streams(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  left_at TIMESTAMP WITH TIME ZONE,
  watch_duration_seconds INTEGER DEFAULT 0,
  UNIQUE(stream_id, user_id)
);

-- Create stream chat messages table
CREATE TABLE IF NOT EXISTS public.stream_chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stream_id UUID NOT NULL REFERENCES public.live_streams(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  message TEXT NOT NULL,
  message_type TEXT DEFAULT 'text' CHECK (message_type IN ('text', 'emoji', 'system')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create stream interactions table
CREATE TABLE IF NOT EXISTS public.stream_interactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stream_id UUID NOT NULL REFERENCES public.live_streams(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  interaction_type TEXT NOT NULL CHECK (interaction_type IN ('like', 'share', 'follow', 'gift')),
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.live_streams ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stream_viewers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stream_chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stream_interactions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for live_streams
CREATE POLICY "streams_select_public_or_own" ON public.live_streams FOR SELECT USING (
  privacy = 'public' OR 
  user_id = auth.uid() OR
  (privacy = 'friends' AND EXISTS (
    SELECT 1 FROM public.friendships 
    WHERE (user_id = auth.uid() AND friend_id = live_streams.user_id AND status = 'accepted') OR
          (friend_id = auth.uid() AND user_id = live_streams.user_id AND status = 'accepted')
  ))
);
CREATE POLICY "streams_insert_own" ON public.live_streams FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "streams_update_own" ON public.live_streams FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "streams_delete_own" ON public.live_streams FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for stream_viewers
CREATE POLICY "viewers_select_own_or_streamer" ON public.stream_viewers FOR SELECT USING (
  user_id = auth.uid() OR 
  EXISTS (SELECT 1 FROM public.live_streams WHERE id = stream_viewers.stream_id AND user_id = auth.uid())
);
CREATE POLICY "viewers_insert_own" ON public.stream_viewers FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "viewers_update_own" ON public.stream_viewers FOR UPDATE USING (auth.uid() = user_id);

-- RLS Policies for stream_chat_messages
CREATE POLICY "chat_select_stream_viewers" ON public.stream_chat_messages FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.live_streams 
    WHERE id = stream_chat_messages.stream_id AND (
      privacy = 'public' OR 
      user_id = auth.uid() OR
      (privacy = 'friends' AND EXISTS (
        SELECT 1 FROM public.friendships 
        WHERE (user_id = auth.uid() AND friend_id = live_streams.user_id AND status = 'accepted') OR
              (friend_id = auth.uid() AND user_id = live_streams.user_id AND status = 'accepted')
      ))
    )
  )
);
CREATE POLICY "chat_insert_own" ON public.stream_chat_messages FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "chat_delete_own_or_streamer" ON public.stream_chat_messages FOR DELETE USING (
  auth.uid() = user_id OR 
  EXISTS (SELECT 1 FROM public.live_streams WHERE id = stream_chat_messages.stream_id AND user_id = auth.uid())
);

-- RLS Policies for stream_interactions
CREATE POLICY "interactions_select_all" ON public.stream_interactions FOR SELECT USING (true);
CREATE POLICY "interactions_insert_own" ON public.stream_interactions FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS streams_user_id_idx ON public.live_streams(user_id);
CREATE INDEX IF NOT EXISTS streams_status_idx ON public.live_streams(status);
CREATE INDEX IF NOT EXISTS streams_category_idx ON public.live_streams(category);
CREATE INDEX IF NOT EXISTS streams_created_at_idx ON public.live_streams(created_at DESC);
CREATE INDEX IF NOT EXISTS stream_viewers_stream_id_idx ON public.stream_viewers(stream_id);
CREATE INDEX IF NOT EXISTS stream_viewers_user_id_idx ON public.stream_viewers(user_id);
CREATE INDEX IF NOT EXISTS stream_chat_stream_id_idx ON public.stream_chat_messages(stream_id);
CREATE INDEX IF NOT EXISTS stream_chat_created_at_idx ON public.stream_chat_messages(created_at DESC);
CREATE INDEX IF NOT EXISTS stream_interactions_stream_id_idx ON public.stream_interactions(stream_id);
