-- Function to increment stream viewer count
CREATE OR REPLACE FUNCTION increment_stream_viewers(stream_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE public.live_streams 
  SET viewer_count = viewer_count + 1,
      max_viewers = GREATEST(max_viewers, viewer_count + 1)
  WHERE id = stream_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to decrement stream viewer count
CREATE OR REPLACE FUNCTION decrement_stream_viewers(stream_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE public.live_streams 
  SET viewer_count = GREATEST(viewer_count - 1, 0)
  WHERE id = stream_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get stream analytics
CREATE OR REPLACE FUNCTION get_stream_analytics(stream_id UUID)
RETURNS TABLE (
  total_viewers INTEGER,
  average_watch_time DECIMAL,
  peak_viewers INTEGER,
  total_messages INTEGER,
  total_likes INTEGER
) AS $$
BEGIN
  RETURN QUERY SELECT
    (SELECT COUNT(DISTINCT user_id)::INTEGER FROM public.stream_viewers WHERE stream_viewers.stream_id = get_stream_analytics.stream_id),
    (SELECT COALESCE(AVG(watch_duration_seconds), 0) FROM public.stream_viewers WHERE stream_viewers.stream_id = get_stream_analytics.stream_id AND left_at IS NOT NULL),
    (SELECT COALESCE(max_viewers, 0)::INTEGER FROM public.live_streams WHERE id = get_stream_analytics.stream_id),
    (SELECT COUNT(*)::INTEGER FROM public.stream_chat_messages WHERE stream_chat_messages.stream_id = get_stream_analytics.stream_id),
    (SELECT COUNT(*)::INTEGER FROM public.stream_interactions WHERE stream_interactions.stream_id = get_stream_analytics.stream_id AND interaction_type = 'like');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
