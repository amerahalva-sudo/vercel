-- Function to increment ad statistics
CREATE OR REPLACE FUNCTION increment_ad_stat(ad_id UUID, stat_field TEXT)
RETURNS VOID AS $$
BEGIN
  IF stat_field = 'impressions' THEN
    UPDATE public.advertisements 
    SET impressions = impressions + 1 
    WHERE id = ad_id;
  ELSIF stat_field = 'clicks' THEN
    UPDATE public.advertisements 
    SET clicks = clicks + 1 
    WHERE id = ad_id;
  ELSIF stat_field = 'conversions' THEN
    UPDATE public.advertisements 
    SET conversions = conversions + 1 
    WHERE id = ad_id;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to calculate ad performance metrics
CREATE OR REPLACE FUNCTION get_ad_performance(ad_id UUID)
RETURNS TABLE (
  ctr DECIMAL,
  conversion_rate DECIMAL,
  cost_per_click DECIMAL,
  cost_per_conversion DECIMAL
) AS $$
DECLARE
  ad_record RECORD;
BEGIN
  SELECT impressions, clicks, conversions, spent_amount 
  INTO ad_record 
  FROM public.advertisements 
  WHERE id = ad_id;
  
  RETURN QUERY SELECT
    CASE WHEN ad_record.impressions > 0 THEN 
      (ad_record.clicks::DECIMAL / ad_record.impressions::DECIMAL) * 100 
    ELSE 0 END as ctr,
    CASE WHEN ad_record.clicks > 0 THEN 
      (ad_record.conversions::DECIMAL / ad_record.clicks::DECIMAL) * 100 
    ELSE 0 END as conversion_rate,
    CASE WHEN ad_record.clicks > 0 THEN 
      ad_record.spent_amount / ad_record.clicks 
    ELSE 0 END as cost_per_click,
    CASE WHEN ad_record.conversions > 0 THEN 
      ad_record.spent_amount / ad_record.conversions 
    ELSE 0 END as cost_per_conversion;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
